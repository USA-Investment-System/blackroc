// ============================================
// 💾 Auto-Save Storage System
// ============================================

const PREFIX = 'br10_';
const listeners: ((key: string) => void)[] = [];
let saveTimer: ReturnType<typeof setTimeout> | null = null;
const saveQueue = new Map<string, unknown>();

// Get value from storage
export function getSync<T>(key: string, fallback: T): T {
  try {
    const v = localStorage.getItem(PREFIX + key);
    if (!v) return fallback;
    return JSON.parse(v) as T;
  } catch {
    return fallback;
  }
}

// Set value immediately
export function setSync(key: string, value: unknown): void {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(value));
    listeners.forEach((l) => l(key));
  } catch (e) {
    console.error('Storage error:', e);
  }
}

// Set value with debounce (auto-save)
export function set(key: string, value: unknown, delay: number = 300): void {
  saveQueue.set(key, value);
  if (saveTimer) clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    saveQueue.forEach((v, k) => setSync(k, v));
    saveQueue.clear();
    saveTimer = null;
  }, delay);
}

// Remove value
export function remove(key: string): void {
  try {
    localStorage.removeItem(PREFIX + key);
  } catch (e) {
    console.error('Storage remove error:', e);
  }
}

// Clear all app data
export function clearAll(): void {
  try {
    const keys = Object.keys(localStorage);
    keys.forEach((k) => {
      if (k.startsWith(PREFIX)) {
        localStorage.removeItem(k);
      }
    });
  } catch (e) {
    console.error('Storage clear error:', e);
  }
}

// Listen for changes
export function onSave(callback: (key: string) => void): () => void {
  listeners.push(callback);
  return () => {
    const i = listeners.indexOf(callback);
    if (i >= 0) listeners.splice(i, 1);
  };
}

// Get all users
export function getUsers(): any[] {
  return getSync('users', []);
}

// Save users
export function saveUsers(users: any[]): void {
  setSync('users', users);
}

// Save tasks for a user
export function saveTasks(userId: number, date: string, tasks: any[]): void {
  setSync('tasks_' + userId, { date, tasks });
}

// Get tasks for a user
export function getTasks(userId: number): { date: string; tasks: any[] } | null {
  return getSync('tasks_' + userId, null);
}
