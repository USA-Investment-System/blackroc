// ============================================
// 📈 Investment Funds System
// ============================================

export interface Fund {
  id: number;
  ar: string;
  en: string;
  descAr: string;
  descEn: string;
  days: number;
  dailyReturn: number;
  totalReturn: number;
  minInvest: number;
  maxInvest: number;
  soldPercent: number;
  isHot: boolean;
  emoji: string;
  color: string;
}

export const FUNDS: Fund[] = [
  {
    id: 1,
    ar: 'صندوق الطاقة المتجددة',
    en: 'Renewable Energy Fund',
    descAr: 'استثمر في مشاريع الطاقة الشمسية والرياح مع عوائد مضمونة',
    descEn: 'Invest in solar and wind projects with guaranteed returns',
    days: 15, dailyReturn: 6.5, totalReturn: 97.5,
    minInvest: 1000, maxInvest: Number.MAX_SAFE_INTEGER,
    soldPercent: 72, isHot: true, emoji: '⚡', color: '#22C55E',
  },
  {
    id: 2,
    ar: 'صندوق استثمار الذهب',
    en: 'Gold Investment Fund',
    descAr: 'استثمار آمن في الذهب مع عوائد يومية ثابتة',
    descEn: 'Safe gold investment with fixed daily returns',
    days: 30, dailyReturn: 4.2, totalReturn: 126,
    minInvest: 1000, maxInvest: Number.MAX_SAFE_INTEGER,
    soldPercent: 85, isHot: false, emoji: '🪙', color: '#D4AF37',
  },
  {
    id: 3,
    ar: 'صندوق التكنولوجيا',
    en: 'Global Tech Fund',
    descAr: 'استثمر في شركات التقنية الكبرى مع عوائد عالية',
    descEn: 'Invest in top tech companies with high returns',
    days: 10, dailyReturn: 8.0, totalReturn: 80,
    minInvest: 1000, maxInvest: Number.MAX_SAFE_INTEGER,
    soldPercent: 54, isHot: true, emoji: '💻', color: '#3B82F6',
  },
  {
    id: 4,
    ar: 'صندوق العقارات',
    en: 'Real Estate Fund',
    descAr: 'عقارات فاخرة مع عوائد شهرية مستقرة',
    descEn: 'Luxury properties with stable monthly returns',
    days: 60, dailyReturn: 2.8, totalReturn: 168,
    minInvest: 1000, maxInvest: Number.MAX_SAFE_INTEGER,
    soldPercent: 38, isHot: false, emoji: '🏢', color: '#A855F7',
  },
  {
    id: 5,
    ar: 'صندوق VIP حصري',
    en: 'VIP Exclusive Fund',
    descAr: 'للمستثمرين المميزين فقط مع أعلى العوائد',
    descEn: 'Premium investors only with highest returns',
    days: 7, dailyReturn: 12.0, totalReturn: 84,
    minInvest: 1000, maxInvest: Number.MAX_SAFE_INTEGER,
    soldPercent: 91, isHot: true, emoji: '💎', color: '#F59E0B',
  },
];

export function calculateDailyProfit(amount: number, dailyReturn: number): number {
  return amount * dailyReturn / 100;
}

export function calculateTotalProfit(amount: number, totalReturn: number): number {
  return amount * totalReturn / 100;
}

export function getDaysLeft(investDate: string, totalDays: number): number {
  const start = new Date(investDate).getTime();
  const now = Date.now();
  const passed = Math.floor((now - start) / 86400000);
  return Math.max(0, totalDays - passed);
}

export function getEarnedSoFar(amount: number, dailyReturn: number, investDate: string, totalDays: number): number {
  const start = new Date(investDate).getTime();
  const now = Date.now();
  const passed = Math.min(Math.floor((now - start) / 86400000), totalDays);
  return amount * dailyReturn / 100 * passed;
}
