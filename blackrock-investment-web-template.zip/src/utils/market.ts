export interface MarketItem {
  s: string;
  v: string;
  up: boolean;
  p: string;
}

export const MARKET_DATA: MarketItem[] = [
  { s: 'BLK', v: '865,42', up: true, p: '1,24' },
  { s: 'د.ج/USD', v: '134,20', up: false, p: '0,15' },
  { s: 'GOLD', v: '2.342,8', up: true, p: '0,82' },
  { s: 'S&P500', v: '5.248', up: true, p: '0,45' },
];
