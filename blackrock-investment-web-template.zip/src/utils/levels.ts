export interface Level {
  id: string;
  n: string;
  p: number;
  d: number;
  dy: number;
  tot: number;
  mo: number;
}

export const LEVELS: Level[] = [
  { id: 'trial', n: 'Starter', p: 0, d: 3, dy: 43, tot: 215, mo: 0 },
  { id: 'm1', n: 'M1', p: 7000, d: 5, dy: 43, tot: 215, mo: 6450 },
  { id: 'm2', n: 'M2', p: 26600, d: 10, dy: 86, tot: 860, mo: 25800 },
  { id: 'm3', n: 'M3', p: 95000, d: 25, dy: 131, tot: 3275, mo: 98250 },
  { id: 'm4', n: 'M4', p: 300000, d: 50, dy: 222, tot: 11100, mo: 333000 },
  { id: 'm5', n: 'M5', p: 780000, d: 80, dy: 390, tot: 31200, mo: 936000 },
  { id: 'm6', n: 'M6', p: 1950000, d: 130, dy: 652, tot: 84760, mo: 2542800 },
  { id: 'g7', n: 'G7 Platinum', p: 4485000, d: 200, dy: 1068, tot: 213600, mo: 6408000 },
];

export function getLevelName(id: string | null): string {
  return LEVELS.find(l => l.id === id)?.n || 'Starter';
}

export function getLevelData(id: string | null): Level {
  return LEVELS.find(l => l.id === id) || LEVELS[0];
}

export function getLevelIndex(id: string | null): number {
  const i = LEVELS.findIndex(l => l.id === id);
  return i >= 0 ? i : 0;
}
