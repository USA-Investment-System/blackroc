// ============================================
// ⚡ Daily Tasks System
// ============================================

export interface TaskTemplate {
  ar: string;
  en: string;
}

export const TASK_TEMPLATES: TaskTemplate[] = [
  { ar: 'مراجعة أداء المحفظة', en: 'Review portfolio performance' },
  { ar: 'قراءة تقرير السوق اليومي', en: 'Read daily market report' },
  { ar: 'تحليل اتجاهات BLK', en: 'Analyze BLK trends' },
  { ar: 'فحص الاستراتيجية اليومية', en: 'Check daily strategy' },
  { ar: 'مشاهدة رسالة استثمارية', en: 'View investment report' },
  { ar: 'تحديث بيانات المحفظة', en: 'Update portfolio data' },
  { ar: 'مراجعة الأرباح والخسائر', en: 'Review P&L statement' },
  { ar: 'تحليل مؤشرات السوق', en: 'Analyze market indicators' },
  { ar: 'متابعة أخبار الاستثمار', en: 'Follow investment news' },
  { ar: 'فحص أداء الأسهم', en: 'Check stock performance' },
  { ar: 'مراجعة عقد الاستثمار', en: 'Review investment contract' },
  { ar: 'تحليل عائد المحفظة', en: 'Analyze portfolio yield' },
];

export function getToday(): string {
  return new Date().toDateString();
}

export function generateDailyTasks(userId: number, perTaskReward: number) {
  const seed = parseInt((getToday().replace(/\D/g, '') || '0').slice(-6)) + (userId % 1000);
  const indices = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
    .sort((a, b) => Math.sin(seed + a) - Math.sin(seed + b))
    .slice(0, 5);

  return indices.map((idx, i) => ({
    id: i + 1,
    ar: TASK_TEMPLATES[idx].ar,
    en: TASK_TEMPLATES[idx].en,
    sec: 40,
    reward: perTaskReward,
    status: 'available' as const,
  }));
}
