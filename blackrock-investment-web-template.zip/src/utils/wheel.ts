import { CURRENCY_SYMBOL } from './money';

export interface WheelPrize {
  l: string;
  v: number;
  cl: string;
}

export const WHEEL_PRIZES: WheelPrize[] = [
  { l: '43 ' + CURRENCY_SYMBOL, v: 43, cl: '#D4AF37' },
  { l: '86 ' + CURRENCY_SYMBOL, v: 86, cl: '#6B4C0A' },
  { l: '215 ' + CURRENCY_SYMBOL, v: 215, cl: '#C9992C' },
  { l: 'Spin+', v: 0, cl: '#7C3AED' },
  { l: '430 ' + CURRENCY_SYMBOL, v: 430, cl: '#B8860B' },
  { l: '86 ' + CURRENCY_SYMBOL, v: 86, cl: '#4A3506' },
  { l: '215 ' + CURRENCY_SYMBOL, v: 215, cl: '#D4AF37' },
  { l: '43 ' + CURRENCY_SYMBOL, v: 43, cl: '#9E7A20' },
];
