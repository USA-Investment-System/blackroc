// ============================================
// 🌍 Translations System (AR / EN)
// ============================================

export type Lang = 'ar' | 'en';

export interface Translations {
  [key: string]: string;
}

export const AR: Translations = {
  // Navigation
  home: 'الرئيسية',
  tasks: 'المهام',
  up: 'الترقية',
  acc: 'حسابي',

  // Balance
  bal: 'إجمالي الرصيد',
  team: 'الفريق',
  done: 'المهام',
  daily: 'اليومي',

  // Referral
  refT: 'الإحالة الذهبية',
  ref2: '5% من دخل كل صديق مدى الحياة',
  copy: 'نسخ',
  share: 'مشاركة',
  ef: 'كل صديق = 🎡 دورة لك + دورة له!',
  lo: '⚡ الرابط يفتح التطبيق مباشرة',

  // Portfolio
  pf: 'أداء المحفظة',
  co: 'الشركة والأمان',
  det: 'التفاصيل',
  earned: 'إجمالي الأرباح',
  refE: 'أرباح الإحالات',
  tod: 'أرباح اليوم',
  mon: 'الأرباح الشهرية',

  // Tasks
  taskT: 'المهام اليومية',
  rew: 'مكافأة',
  start: 'ابدأ',
  doneL: 'مكتملة',
  failL: 'أُلغيت',
  wait: 'انتظر',
  sec: 'ثانية',
  cancel: 'إلغاء المهمة',
  chg: 'تتغير يومياً حسب مستواك',

  // Plans
  plans: 'خطط الاستثمار',
  avail: 'رصيدك المتاح',
  free: 'مجاني',
  active: 'مفعّل',
  upBtn: 'ترقية',
  dy: 'يومي',
  days: 'أيام',
  tot: 'الإجمالي',
  mo: 'شهري',

  // Account
  myAcc: 'حسابي',
  refCode: 'رابط الدعوة',
  secT: 'الأمان والعقد',
  aboutT: 'عن الشركة',
  refsT: 'إحالاتي',
  wheel: 'عجلة الحظ',
  setT: 'الإعدادات',
  out: 'تسجيل الخروج',

  // Competition
  compT: '🏆 مسابقة الإحالة',
  compS: '10 أصدقاء = ترقية مجانية!',
  prog: 'تقدمك',
  goal: 'الهدف: 10 أصدقاء M1',

  // Wheel
  spin: 'اضغط للدوران',
  noSpin: 'لا دورات متبقية',
  prize: 'الجائزة',

  // Auth
  signIn: 'تسجيل الدخول',
  signUp: 'إنشاء حساب',
  user: 'اسم المستخدم',
  pass: 'كلمة المرور',
  conf: 'تأكيد كلمة المرور',
  noAcc: 'ليس لديك حساب؟ سجل مجاناً',
  hasAcc: 'لديك حساب؟ سجل الدخول',
  show: 'عرض',
  hide: 'إخفاء',
  waitAuth: 'جاري...',

  // Notifications
  notifs: 'الإشعارات',
  noNotifs: 'لا توجد إشعارات',

  // Task Cancel
  cnfT: 'تأكيد الإلغاء',
  keepT: 'إكمال المهمة',
  cnfB: 'إلغاء نهائي',

  // Withdrawal
  wLock: 'السحب مقفل',
  wReq: 'يتطلب M1 + 10,000 د.ج',
  wd: 'سحب',
  qwd: 'السحب السريع',

  // Other
  sup: 'تواصل مع الدعم',
  copied: 'تم النسخ!',
  lang: 'English',
  aiP: 'اكتب سؤالك...',
  avT: 'اختر صورتك',
  clear: 'مسح البيانات',
  totRef: 'إجمالي الإحالات',
  refDzd: 'د.ج من الإحالات',
  sub: 'منصة الاستثمار',

  // Company
  contract: 'تقر شركة BlackRock, Inc بأنها أبرمت عقداً رسمياً مع الجانب الجزائري في يناير 2025 مدته 3 سنوات ينتهي في ديسمبر 2027.',
  coDesc: 'تأسست عام 1988 في نيويورك، وهي أكبر شركة لإدارة الأصول في العالم مع أكثر من 10.2 تريليون دولار من الأصول المدارة.',
  coSec: 'نستخدم تشفير AES-256 العسكري مع SSL/TLS 3.0 لحماية جميع بيانات المستخدمين والمعاملات.',
  coAlg: 'عقد رسمي مع الجزائر يبدأ من يناير 2025 وينتهي في ديسمبر 2027، مدته 3 سنوات كاملة.',
};

export const EN: Translations = {
  home: 'Home', tasks: 'Tasks', up: 'Plans', acc: 'Account',
  bal: 'Total Balance', team: 'Team', done: 'Tasks', daily: 'Daily',
  refT: 'Golden Referral', ref2: "5% of each friend's income for life",
  copy: 'Copy', share: 'Share',
  ef: 'Each friend = 🎡 spin for you + spin for them!',
  lo: '⚡ Link opens app directly',
  pf: 'Portfolio', co: 'Company & Security', det: 'Details',
  earned: 'Total Earned', refE: 'Referral Earnings', tod: "Today's Profit", mon: 'Monthly',
  taskT: 'Daily Tasks', rew: 'Reward', start: 'Start', doneL: 'Done', failL: 'Cancelled',
  wait: 'Wait', sec: 'sec', cancel: 'Cancel Task', chg: 'Changes daily by level',
  plans: 'Investment Plans', avail: 'Available Balance',
  free: 'FREE', active: 'Active', upBtn: 'Upgrade',
  dy: 'Daily', days: 'Days', tot: 'Total', mo: 'Monthly',
  myAcc: 'My Account', refCode: 'Referral Link',
  secT: 'Security & Contract', aboutT: 'About BlackRock', refsT: 'Referrals',
  wheel: 'Lucky Wheel', setT: 'Settings', out: 'Sign Out',
  compT: '🏆 Referral Contest', compS: '10 friends = Free upgrade!',
  prog: 'Progress', goal: 'Goal: 10 M1 friends',
  spin: 'SPIN NOW', noSpin: 'No spins left', prize: 'PRIZE',
  signIn: 'Sign In', signUp: 'Create Account',
  user: 'Username', pass: 'Password', conf: 'Confirm Password',
  noAcc: "Don't have account? Sign up", hasAcc: 'Have account? Sign in',
  show: 'Show', hide: 'Hide', waitAuth: 'Wait...',
  notifs: 'Notifications', noNotifs: 'No notifications',
  cnfT: 'Cancel Task?', keepT: 'Keep Going', cnfB: 'Cancel Anyway',
  wLock: 'Withdrawal Locked', wReq: 'Requires M1 + 10,000 د.ج',
  wd: 'Withdraw', qwd: 'Quick Withdraw',
  sup: 'Contact Support', copied: 'Copied!', lang: 'عربي',
  aiP: 'Ask me anything...', avT: 'Choose Avatar', clear: 'Clear Data',
  totRef: 'Total Referrals', refDzd: 'د.ج from Referrals',
  sub: 'Investment Platform',
  contract: 'BlackRock, Inc signed an official contract with Algeria in January 2025, valid for 3 years until December 2027.',
  coDesc: "Founded in 1988 in New York, BlackRock is the world's largest asset manager with over $10.2 trillion in AUM.",
  coSec: 'We use military-grade AES-256 encryption with SSL/TLS 3.0 to protect all user data and transactions.',
  coAlg: 'Official contract with Algeria starting January 2025 until December 2027, spanning 3 full years.',
};

export const TRANSLATIONS: Record<Lang, Translations> = { ar: AR, en: EN };

export function t(lang: Lang, key: string): string {
  return TRANSLATIONS[lang][key] || key;
}
