// ============================================
// 🇩🇿 Algerian Dinar (د.ج) Currency System
// ============================================

// Currency constants
export const CURRENCY_AR = 'د.ج';
export const CURRENCY_EN = 'DA';
export const CURRENCY_CODE = 'DZD';
export const CURRENCY_SYMBOL = 'د.ج';
export const CURRENCY_LOCALE = 'fr-DZ';

// Format number with Algerian style (1 234,56)
export function formatNumber(n: number, decimals: number = 2): string {
  const num = parseFloat(String(n)) || 0;
  if (num >= 1_000_000) {
    return (num / 1_000_000).toFixed(2).replace('.', ',') + 'M';
  }
  if (num >= 1_000) {
    return (num / 1_000).toFixed(1).replace('.', ',') + 'K';
  }
  return num.toLocaleString(CURRENCY_LOCALE, {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

// Format compact (no decimals for large numbers)
export function formatCompact(n: number): string {
  const num = parseFloat(String(n)) || 0;
  if (num >= 1_000_000) {
    return (num / 1_000_000).toFixed(1).replace('.', ',') + 'M';
  }
  if (num >= 1_000) {
    return (num / 1_000).toFixed(0) + 'K';
  }
  return num.toLocaleString(CURRENCY_LOCALE, {
    maximumFractionDigits: 0,
  });
}

// Format with currency symbol: "1 234,56 د.ج"
export function formatCurrency(n: number): string {
  return formatNumber(n) + ' ' + CURRENCY_SYMBOL;
}

// Format integer with currency: "1 234 د.ج"
export function formatCurrencyInt(n: number): string {
  return formatCompact(n) + ' ' + CURRENCY_SYMBOL;
}

// Format for display in cards (short): "+43 د.ج"
export function formatReward(n: number): string {
  return '+' + formatCompact(n) + ' ' + CURRENCY_SYMBOL;
}

// Format range: "3 000 ~ 5 000 000 د.ج"
export function formatRange(min: number, max: number): string {
  return formatCompact(min) + ' ~ ' + formatCompact(max) + ' ' + CURRENCY_SYMBOL;
}
