import { useEffect, useRef } from 'react';
import { useStore } from '../store';
import { T, fmt, lvN, lvD, today, TASKS_AR, TASKS_EN } from '../utils';
import { Zap, Lock, X, Rocket, Check } from 'lucide-react';

export function Tasks() {
  const { user, lang, tasks, setTasks, activeTask, cdVal, setActive, decCd, updTask, toast2, setSheet } = useStore();
  const t = T[lang];
  const timerRef = useRef<any>(null);
  const hasLevel = Boolean(user?.level);
  const taskCountForLevel = (levelId: string | null | undefined) => {
    const level = lvD(levelId || 'trial');
    return level.id === 'trial' ? 5 : level.d;
  };
  const buildTasks = (levelId: string | null | undefined, userId: number) => {
    const level = lvD(levelId || 'trial');
    const count = taskCountForLevel(levelId);
    const reward = level.dy;
    const seed = parseInt((today().replace(/\D/g, '') || '0').slice(-6)) + ((userId || 0) % 1000) + (level.id.length * 17);
    const order = Array.from({ length: TASKS_AR.length }, (_, i) => i).sort((a, b) => Math.sin(seed + a) - Math.sin(seed + b));
    return Array.from({ length: count }, (_, i) => {
      const c = order[i % order.length];
      const round = Math.floor(i / order.length) + 1;
      return {
        id: i + 1,
        ar: TASKS_AR[c] + (round > 1 ? ` ${round}` : ''),
        en: TASKS_EN[c] + (round > 1 ? ` ${round}` : ''),
        sec: 40,
        reward,
        status: 'available' as const,
      };
    });
  };

  useEffect(() => {
    if (!user) return;
    const saved = localStorage.getItem('tk9_' + user.id);
    let tk = null;
    if (saved) { const p = JSON.parse(saved); if (p.date === today() && p.level === (user.level || 'none')) tk = p.tasks; }
    if (!tk) {
      tk = buildTasks(user.level, user.id);
      localStorage.setItem('tk9_' + user.id, JSON.stringify({ date: today(), level: user.level || 'none', tasks: tk }));
    }
    if (!tasks || tasks.length !== tk.length || tasks.some(t => t.reward !== lvD(user.level || 'trial').dy)) setTasks(tk);
  }, [user?.id, user?.level]);

  useEffect(() => {
    if (!hasLevel && activeTask !== null) {
      setActive(null);
      return;
    }
    if (activeTask !== null && cdVal > 0) {
      timerRef.current = setInterval(decCd, 1000);
    } else if (activeTask !== null && cdVal <= 0) {
      if (timerRef.current) clearInterval(timerRef.current);
      completeTask(activeTask);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [activeTask, cdVal]);

  const saveTk = (tk: any[]) => { if (user) localStorage.setItem('tk9_' + user.id, JSON.stringify({ date: today(), level: user.level || 'none', tasks: tk })); };
  const startTask = (id: number) => {
    if (!hasLevel) {
      toast2(lang === 'ar' ? 'فعّل التجربة المجانية أولاً' : 'Activate free trial first', 'warning');
      useStore.getState().setTab('up');
      return;
    }
    if (activeTask !== null) { toast2(lang === 'ar' ? 'مهمة جارية!' : 'Task in progress!', 'warning'); return; }
    const tk = tasks?.find(x => x.id === id);
    if (!tk || tk.status !== 'available') return;
    updTask(id, 'active'); setActive(id, tk.sec);
    if (tasks) saveTk(tasks.map(x => x.id === id ? { ...x, status: 'active' } : x));
    toast2(lang === 'ar' ? '⏱️ المهمة بدأت!' : '⏱️ Task started!', 'info');
  };
  const completeTask = (id: number) => {
    const tk = tasks?.find(x => x.id === id);
    if (!tk || !user) return;
    updTask(id, 'done'); setActive(null);
    useStore.getState().updUser({ balance: (user.balance || 0) + tk.reward, taskBal: (user.taskBal || 0) + tk.reward, totalEarned: (user.totalEarned || 0) + tk.reward });
    if (tasks) saveTk(tasks.map(x => x.id === id ? { ...x, status: 'done' } : x));
    toast2(`✓ +${tk.reward} د.ج!`, 'success');
  };
  const cancelTask = (id: number) => {
    const tk = tasks?.find(x => x.id === id); if (!tk) return;
    setSheet(
      <div style={{textAlign:'center',padding:'8px 0'}}>
        <div style={{width:48,height:48,background:'rgba(239,68,68,.1)',borderRadius:16,display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 12px',color:'#EF4444'}}><X size={24} /></div>
        <p style={{color:'#fff',fontWeight:800,fontSize:16,marginBottom:6}}>{t.cnfT}</p>
        <p style={{color:'rgba(255,255,255,.4)',fontSize:13,marginBottom:16}}>{lang === 'ar' ? `ستخسر ${tk.reward} د.ج!` : `You'll lose ${tk.reward} د.ج!`}</p>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
          <button onClick={() => useStore.getState().closeSheet()} style={{background:'rgba(255,255,255,.05)',border:'1px solid rgba(255,255,255,.08)',color:'#fff',borderRadius:12,padding:'12px 0',fontSize:13,fontWeight:800,cursor:'pointer'}}>{t.keepT}</button>
          <button onClick={() => { updTask(id, 'failed'); setActive(null); if (tasks) saveTk(tasks.map(x => x.id === id ? { ...x, status: 'failed' } : x)); useStore.getState().closeSheet(); toast2(lang === 'ar' ? '❌ أُلغيت' : '❌ Cancelled', 'error'); }} style={{background:'#EF4444',border:'none',color:'#fff',borderRadius:12,padding:'12px 0',fontSize:13,fontWeight:800,cursor:'pointer'}}>{t.cnfB}</button>
        </div>
      </div>, ''
    );
  };

  if (!tasks || !user) return null;
  const doneC = tasks.filter(x => x.status === 'done').length;
  const totalR = tasks.filter(x => x.status === 'done').reduce((s, x) => s + x.reward, 0);
  const MIN_WITHDRAW = 10000;
  const pct = Math.min((user.taskBal || 0) / MIN_WITHDRAW * 100, 100);
  const totalTasks = tasks.length;

  return (
    <div className="an-enter" style={{paddingBottom:16}}>
      {/* Header */}
      <div style={{position:'sticky',top:0,zIndex:40,background:'rgba(2,5,9,.97)',padding:'10px 16px',borderBottom:'1px solid rgba(212,175,55,.06)'}}>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between'}}>
          <div style={{display:'flex',alignItems:'center',gap:8}}>
            <div className="bg-gold" style={{width:28,height:28,borderRadius:8,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,color:'#020509'}}><Zap size={15} /></div>
            <div><p style={{color:'#fff',fontWeight:800,fontSize:15}}>{t.taskT}</p><p style={{color:'rgba(255,255,255,.25)',fontSize:9,fontWeight:700}}>{t.chg}</p></div>
          </div>
          <span style={{background:hasLevel?'rgba(212,175,55,.06)':'rgba(239,68,68,.08)',border:hasLevel?'1px solid rgba(212,175,55,.12)':'1px solid rgba(239,68,68,.16)',borderRadius:99,padding:'2px 10px',color:hasLevel?'#D4AF37':'#EF4444',fontSize:9,fontWeight:800}}>{hasLevel ? lvN(user.level) : (lang === 'ar' ? 'غير مفعل' : 'Inactive')}</span>
        </div>
      </div>

      <div style={{padding:'12px 16px',display:'flex',flexDirection:'column',gap:10}}>
        {!hasLevel && (
          <div style={{background:'linear-gradient(135deg,rgba(212,175,55,.10),rgba(239,68,68,.05))',border:'1px solid rgba(212,175,55,.22)',borderRadius:16,padding:14,textAlign:'center'}}>
            <div style={{width:46,height:46,background:'rgba(212,175,55,.12)',border:'1px solid rgba(212,175,55,.25)',borderRadius:14,display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 10px',color:'#D4AF37'}}><Lock size={22}/></div>
            <p style={{color:'#fff',fontWeight:900,fontSize:15,marginBottom:5}}>{lang === 'ar' ? 'المهام مقفلة حالياً' : 'Tasks are locked'}</p>
            <p style={{color:'rgba(255,255,255,.45)',fontSize:12,lineHeight:1.7,marginBottom:12}}>{lang === 'ar' ? 'يجب تفعيل التجربة المجانية أو أي مستوى استثماري قبل تشغيل المهام اليومية.' : 'Activate the free trial or any investment level before starting daily tasks.'}</p>
            <button onClick={()=>useStore.getState().setTab('up')} className="bg-gold" style={{width:'100%',border:'none',borderRadius:12,color:'#020509',padding:'12px 0',fontSize:14,fontWeight:900,cursor:'pointer',fontFamily:'Tajawal,sans-serif'}}>✓ {lang === 'ar' ? 'تفعيل التجربة المجانية' : 'Activate Free Trial'}</button>
          </div>
        )}
        {/* Stats */}
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:6}}>
          {[{v:`${doneC}/${totalTasks}`,l:'DONE',c:'#22C55E'},{v:String(totalR),l:'د.ج',c:'#D4AF37'},{v:String(user.teamCount||0),l:'TEAM',c:'#3B82F6'}].map((s,i)=>(
            <div key={i} style={{background:'rgba(255,255,255,.03)',border:'1px solid rgba(255,255,255,.05)',borderRadius:14,padding:'10px 4px',textAlign:'center'}}>
              <p className="font-mon" style={{fontSize:15,fontWeight:900,color:s.c}}>{s.v}</p>
              <p style={{color:'rgba(255,255,255,.25)',fontSize:9,fontWeight:700,letterSpacing:1,marginTop:2}}>{s.l}</p>
            </div>
          ))}
        </div>

        {/* Lock */}
        <div className="bg-card" style={{border:'1px solid rgba(239,68,68,.18)',borderRadius:16,padding:12,position:'relative',overflow:'hidden'}}>
          <div style={{position:'absolute',top:4,right:8,opacity:.04}}><Lock size={44} /></div>
          <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:6}}><Lock size={13} style={{color:'#EF4444',flexShrink:0}} /><span style={{color:'#F87171',fontSize:12,fontWeight:800}}>{t.wLock}</span></div>
          <div style={{background:'rgba(255,255,255,.07)',borderRadius:4,height:4,overflow:'hidden',marginBottom:4}}><div style={{height:'100%',background:'linear-gradient(90deg,#EF4444,#F87171)',borderRadius:4,width:`${pct}%`,transition:'width .5s'}} /></div>
          <div style={{display:'flex',justifyContent:'space-between',color:'rgba(255,255,255,.3)',fontSize:10,fontWeight:700}}><span>{fmt(user.taskBal||0)} د.ج</span><span>{fmt(MIN_WITHDRAW)} د.ج</span></div>
        </div>

        {/* Tasks */}
        {(!hasLevel ? tasks.slice(0, 3) : tasks).map(tk => {
          const isAct = activeTask === tk.id && tk.status === 'active';
          const prog = tk.status === 'done' ? 100 : (isAct ? ((tk.sec - cdVal) / tk.sec * 100) : 0);
          const nm = lang === 'ar' ? tk.ar : tk.en;
          const isDone = tk.status === 'done';
          const isFail = tk.status === 'failed';
          const borderColor = isDone ? 'rgba(34,197,94,.18)' : isFail ? 'rgba(239,68,68,.1)' : isAct ? 'rgba(212,175,55,.3)' : 'rgba(255,255,255,.05)';
          const iconBg = isDone ? 'rgba(34,197,94,.08)' : isFail ? 'rgba(239,68,68,.06)' : undefined;
          const iconColor = isDone ? '#22C55E' : isFail ? '#EF4444' : '#020509';
          const numColor = isDone ? '#22C55E' : isFail ? 'rgba(239,68,68,.35)' : '#D4AF37';
          const progColor = isDone ? 'linear-gradient(90deg,#22C55E,#4ADE80)' : isFail ? '#EF4444' : 'linear-gradient(135deg,#D4AF37,#C9992C)';
          const Icon = isDone ? Check : isFail ? X : Rocket;

          return (
            <div key={tk.id} className="bg-card" style={{border:`1px solid ${borderColor}`,borderRadius:16,padding:14,opacity:isFail?.55:1,transition:'all .3s'}}>
              <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:10}}>
                <div style={{display:'flex',alignItems:'center',gap:10,minWidth:0}}>
                  <div className={isDone||isFail?'':'bg-gold'} style={{width:40,height:40,borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,color:iconColor,...(iconBg?{background:iconBg}:{})}}>
                    <Icon size={20} />
                  </div>
                  <div style={{minWidth:0}}>
                    <p style={{color:isFail?'rgba(255,255,255,.25)':'#fff',fontWeight:800,fontSize:13,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{nm}</p>
                    <p style={{color:'rgba(255,255,255,.25)',fontSize:10,fontWeight:700,marginTop:1}}>{t.rew}: {tk.reward} د.ج · {tk.sec} {t.sec}</p>
                  </div>
                </div>
                <span className="font-mon" style={{fontSize:16,fontWeight:900,color:numColor,flexShrink:0}}>+{tk.reward}</span>
              </div>
              <div style={{background:'rgba(255,255,255,.05)',borderRadius:4,height:4,marginBottom:10,overflow:'hidden'}}><div style={{height:'100%',borderRadius:4,width:`${prog}%`,background:progColor,transition:'width .3s'}} /></div>

              {isAct ? <>
                <div style={{background:'rgba(10,16,32,.95)',border:'1px solid rgba(212,175,55,.12)',borderRadius:16,padding:'16px 12px',textAlign:'center',marginBottom:10}}>
                  <p style={{color:'rgba(255,255,255,.35)',fontSize:10,fontWeight:700,letterSpacing:1,marginBottom:4}}>{t.wait.toUpperCase()}</p>
                  <p className="font-mon tg" style={{fontSize:44,fontWeight:900,lineHeight:1}}>{cdVal}</p>
                  <p style={{color:'rgba(255,255,255,.25)',fontSize:10,fontWeight:700,marginTop:4}}>{t.sec.toUpperCase()}</p>
                  <div style={{background:'rgba(255,255,255,.06)',borderRadius:3,height:3,marginTop:12,overflow:'hidden'}}><div style={{height:'100%',background:'linear-gradient(135deg,#D4AF37,#C9992C)',borderRadius:3,width:`${prog}%`,transition:'width .5s'}} /></div>
                </div>
                <button onClick={()=>cancelTask(tk.id)} style={{width:'100%',background:'rgba(239,68,68,.08)',border:'1px solid rgba(239,68,68,.15)',color:'#EF4444',borderRadius:12,padding:'12px 0',fontSize:13,fontWeight:800,display:'flex',alignItems:'center',justifyContent:'center',gap:6,cursor:'pointer'}}><X size={15} /> {t.cancel}</button>
              </> : tk.status === 'available' ?
                <button onClick={()=>startTask(tk.id)} className={hasLevel ? 'bg-gold' : ''} style={{width:'100%',border:hasLevel?'none':'1px solid rgba(212,175,55,.18)',background:hasLevel?undefined:'rgba(212,175,55,.07)',color:hasLevel?'#020509':'#D4AF37',borderRadius:12,padding:'12px 0',fontSize:14,fontWeight:800,display:'flex',alignItems:'center',justifyContent:'center',gap:6,cursor:'pointer'}}>{hasLevel ? <Rocket size={16} /> : <Lock size={16}/>} {hasLevel ? `${t.start} — ${tk.sec} ${t.sec}` : (lang === 'ar' ? 'فعّل المستوى أولاً' : 'Activate level first')}</button>
              : isDone ?
                <div style={{width:'100%',background:'rgba(34,197,94,.06)',border:'1px solid rgba(34,197,94,.15)',color:'#22C55E',borderRadius:12,padding:'12px 0',fontSize:13,fontWeight:800,display:'flex',alignItems:'center',justifyContent:'center',gap:6}}><Check size={16} /> {t.doneL} ✅ +{tk.reward} د.ج</div>
              :
                <div style={{width:'100%',background:'rgba(239,68,68,.06)',border:'1px solid rgba(239,68,68,.12)',color:'#EF4444',borderRadius:12,padding:'10px 0',fontSize:12,fontWeight:800,display:'flex',alignItems:'center',justifyContent:'center',gap:6,opacity:.55}}><X size={14} /> {t.failL}</div>
              }
            </div>
          );
        })}
        {!hasLevel && (
          <div style={{background:'rgba(255,255,255,.025)',border:'1px dashed rgba(212,175,55,.18)',borderRadius:16,padding:14,textAlign:'center'}}>
            <p style={{color:'rgba(255,255,255,.42)',fontSize:12,lineHeight:1.8,fontWeight:700}}>{lang === 'ar' ? 'هذه معاينة فقط. بعد التفعيل ستظهر كل المهام وتبدأ الأرباح اليومية.' : 'Preview only. Activate a level to unlock all daily earning tasks.'}</p>
          </div>
        )}
      </div>
    </div>
  );
}
