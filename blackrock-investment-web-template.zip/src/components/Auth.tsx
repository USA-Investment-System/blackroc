import { useState } from 'react';
import { useStore } from '../store';
import { T } from '../utils';
import { Shield, Diamond, Eye, EyeOff } from 'lucide-react';
import { createUser, findUserByCode, loginUser, normalizeUser, saveUser, usernameExists } from '../backend';
import { WILAYAS, cleanAlgerianPhoneInput, normalizeAlgerianPhone } from '../utils/algeria';

const AVATAR_STYLES = ['avataaars', 'lorelei', 'micah'];
const AVATAR_SEEDS = ['Ahmed', 'Amina', 'Yacine', 'Sofia', 'Karim', 'Lina', 'Nassim', 'Rania'];
const avatarUrl = (style: string, seed: string) =>
  `https://api.dicebear.com/7.x/${style}/svg?seed=${encodeURIComponent(seed)}&backgroundColor=0f172a,1e293b,312e81`;
const randomAvatar = () => avatarUrl(
  AVATAR_STYLES[Math.floor(Math.random() * AVATAR_STYLES.length)],
  AVATAR_SEEDS[Math.floor(Math.random() * AVATAR_SEEDS.length)]
);

export function Auth() {
  const { lang, toggleLang, setUser, toast2 } = useStore();
  const t = T[lang];
  const joinCode = (() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const queryRef = params.get('code') || params.get('ref');
      if (queryRef) return queryRef.trim().toUpperCase();
      const hash = window.location.hash || '';
      const match = hash.match(/(?:code|ref)=([^&]+)/i);
      return match ? decodeURIComponent(match[1]).trim().toUpperCase() : '';
    } catch {
      return '';
    }
  })();
  const buildRefLink = (code: string) => {
    try {
      const basePath = window.location.pathname.replace(/\/?index\.html$/i, '').replace(/\/$/, '');
      return `${window.location.origin}${basePath || ''}?code=${code}`;
    } catch {
      return 'blackrock.app?code=' + code;
    }
  };
  const [isLogin, setIsLogin] = useState(true);
  const [un, setUn] = useState('');
  const [pw, setPw] = useState('');
  const [cpw, setCpw] = useState('');
  const [phone, setPhone] = useState('');
  const [wilaya, setWilaya] = useState('');
  const [showWilayas, setShowWilayas] = useState(false);
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);

  const go = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!un || !pw) { toast2(lang === 'ar' ? 'يرجى ملء الحقول' : 'Fill all fields', 'error'); return; }
    if (!isLogin && pw !== cpw) { toast2(lang === 'ar' ? 'كلمتا المرور مختلفتان' : "Passwords don't match", 'error'); return; }
    const normalizedPhone = normalizeAlgerianPhone(phone);
    if (!isLogin && !normalizedPhone) { toast2(lang === 'ar' ? 'أدخل رقم جزائري صحيح' : 'Enter a valid Algerian phone', 'error'); return; }
    if (!isLogin && !wilaya.trim()) { toast2(lang === 'ar' ? 'أدخل الولاية' : 'Enter wilaya', 'error'); return; }
    setLoading(true);
    try {
      setLoading(false);
      if (isLogin) {
        const f = await loginUser(un, pw);
        if (f) { setUser(f); toast2('👋 ' + un, 'success'); }
        else toast2(lang === 'ar' ? 'بيانات خاطئة' : 'Wrong credentials', 'error');
      } else {
        if (await usernameExists(un)) { toast2(lang === 'ar' ? 'الاسم موجود' : 'Username taken', 'error'); return; }
        const code = Math.random().toString(36).substring(2, 8).toUpperCase();
        const newAvatar = randomAvatar();
        const referrer = joinCode ? await findUserByCode(joinCode) : null;
        if (referrer) {
          referrer.teamCount = (referrer.teamCount || 0) + 1;
          referrer.wheelSpins = (referrer.wheelSpins || 0) + 1;
          referrer.team = [
            ...(referrer.team || []),
            { id: Date.now(), username: un, code, joined: new Date().toISOString(), avatar: newAvatar, level: null, active: true }
          ];
          referrer.notifs = [
            ...(referrer.notifs || []),
            {
              id: Date.now(),
              title: '🎡 ' + (lang === 'ar' ? 'صديق جديد انضم!' : 'New friend joined!'),
              desc: un + (lang === 'ar' ? ' سجل برابطك. حصلت على دورة عجلة حظ.' : ' joined with your link. You earned a lucky spin.'),
              t: new Date().toLocaleTimeString(),
              r: false,
            }
          ];
          await saveUser(referrer);
        }
        const nu = normalizeUser({
          id: Date.now(), un, pw, code, ref: buildRefLink(code), phone: normalizedPhone, wilaya: wilaya.trim(), profileCompleted: true,
          balance: 0, taskBal: 0, refEarn: 0, teamCount: 0, wheelSpins: joinCode ? 1 : 0,
          m1Refs: 0, level: null, totalEarned: 0, avatar: newAvatar,
          joined: new Date().toISOString(), joinedVia: referrer ? joinCode : null,
          investments: [], investEarned: 0, withdrawals: [], upgradeRequests: [], team: [], showLiveActivity: true, lastLogin: new Date().toDateString(), loginStreak: 1,
          badges: ['founder'], activityLog: [new Date().toLocaleString() + ' - account created'],
          notifs: [
            { id: 1, title: '👋 ' + (lang === 'ar' ? 'مرحباً!' : 'Welcome!'), desc: referrer ? (lang === 'ar' ? 'سجلت عبر رابط صديق. حصلت على دورة عجلة حظ مجانية!' : 'You joined via a friend link. You got a free lucky spin!') : (lang === 'ar' ? 'ابدأ المهام اليومية للربح' : 'Start daily tasks to earn'), t: 'Now', r: false },
            { id: 2, title: '🏆 ' + (lang === 'ar' ? 'مسابقة الإحالة' : 'Referral Contest'), desc: lang === 'ar' ? '10 أصدقاء = ترقية مجانية!' : '10 friends = Free upgrade!', t: 'Now', r: false }
          ]
        });
        const saved = await createUser(nu, pw);
        setUser(saved);
        toast2('🎉 ' + (lang === 'ar' ? 'مرحباً!' : 'Welcome!'), 'success');
      }
    } catch (err) {
      console.error(err);
      toast2(lang === 'ar' ? 'خطأ في الاتصال بقاعدة البيانات' : 'Database connection error', 'error');
    } finally {
      setLoading(false);
    }
  };

  const inputStyle: React.CSSProperties = {
    width: '100%',
    background: 'rgba(255,255,255,.04)',
    border: '1px solid rgba(255,255,255,.1)',
    borderRadius: 14,
    color: '#fff',
    padding: '14px 16px',
    fontSize: 15,
    fontWeight: 700,
    outline: 'none',
    fontFamily: 'Tajawal, sans-serif',
  };

  const labelStyle: React.CSSProperties = {
    display: 'block',
    color: 'rgba(255,255,255,.5)',
    fontSize: 11,
    fontWeight: 800,
    letterSpacing: 1,
    marginBottom: 8,
  };

  return (
    <div style={{
      position: 'absolute', inset: 0,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      padding: '20px 24px',
      overflowY: 'auto',
      WebkitOverflowScrolling: 'touch',
    }}>
      {/* Background glow */}
      <div style={{
        position: 'absolute', top: 0, left: 0, right: 0, height: '40%',
        background: 'radial-gradient(ellipse at 50% -20%, rgba(212,175,55,.06), transparent 68%)',
        pointerEvents: 'none',
      }} />

      <div className="an-enter" style={{ position: 'relative', zIndex: 1, width: '100%', maxWidth: 370 }}>
        {joinCode && (
          <div style={{
            background: 'linear-gradient(135deg, rgba(212,175,55,.12), rgba(34,197,94,.06))',
            border: '1px solid rgba(212,175,55,.28)',
            borderRadius: 16,
            padding: 14,
            textAlign: 'center',
            marginBottom: 16,
          }}>
            <p style={{ color: '#D4AF37', fontSize: 13, fontWeight: 900, marginBottom: 4 }}>🎁 {lang === 'ar' ? 'دعوة صديق مفعلة' : 'Referral Invite Active'}</p>
            <p style={{ color: 'rgba(255,255,255,.48)', fontSize: 12, fontWeight: 700 }}>{lang === 'ar' ? 'سجل الآن لتحصل على دورة عجلة حظ مجانية' : 'Sign up now to get a free lucky wheel spin'}</p>
          </div>
        )}
        {/* Logo - centered */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: 32 }}>
          <div style={{
            width: 72, height: 72,
            background: 'linear-gradient(135deg, #D4AF37, #C9992C, #B8860B)',
            borderRadius: 18,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            marginBottom: 16,
            boxShadow: '0 0 24px rgba(212,175,55,.4)',
          }} className="an-glow">
            <Diamond size={36} strokeWidth={2.5} color="#020509" />
          </div>

          <h1 style={{
            fontFamily: 'Montserrat, sans-serif',
            fontSize: 26, fontWeight: 900, letterSpacing: 4,
          }} className="tg">BLACKROCK</h1>

          <p style={{ color: 'rgba(255,255,255,.35)', fontSize: 11, fontWeight: 700, letterSpacing: 2, marginTop: 4 }}>
            {t.sub.toUpperCase()}
          </p>

          {/* Badges */}
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 14, flexWrap: 'wrap' }}>
            <span style={{
              background: 'rgba(34,197,94,.08)', border: '1px solid rgba(34,197,94,.22)',
              borderRadius: 99, padding: '3px 10px',
              display: 'inline-flex', alignItems: 'center', gap: 4,
            }}>
              <Shield size={11} color="#22C55E" />
              <span style={{ color: '#22C55E', fontSize: 10, fontWeight: 800 }}>SSL V3</span>
            </span>
            <span style={{
              background: 'rgba(212,175,55,.07)', border: '1px solid rgba(212,175,55,.2)',
              borderRadius: 99, padding: '3px 10px',
            }}>
              <span style={{ color: '#D4AF37', fontSize: 10, fontWeight: 800 }}>NYSE:BLK</span>
            </span>
            <button onClick={toggleLang} style={{
              background: 'rgba(255,255,255,.06)', border: '1px solid rgba(255,255,255,.12)',
              borderRadius: 99, padding: '3px 10px',
              color: 'rgba(255,255,255,.55)', fontSize: 10, fontWeight: 800, cursor: 'pointer',
              fontFamily: 'Tajawal, sans-serif',
            }}>
              {t.lang}
            </button>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={go} autoComplete="off" style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {/* Username */}
          <div>
            <label style={labelStyle}>{t.user}</label>
            <input
              value={un} onChange={e => setUn(e.target.value)}
              style={inputStyle}
              placeholder={t.user}
            />
          </div>

          {/* Password */}
          <div>
            <label style={labelStyle}>{t.pass}</label>
            <div style={{ position: 'relative' }}>
              <input
                type={showPw ? 'text' : 'password'}
                value={pw} onChange={e => setPw(e.target.value)}
                style={{ ...inputStyle, paddingLeft: lang === 'ar' ? 16 : 50, paddingRight: lang === 'ar' ? 50 : 16 }}
                placeholder={t.pass}
              />
              <button type="button" onClick={() => setShowPw(!showPw)} style={{
                position: 'absolute', top: '50%', transform: 'translateY(-50%)',
                ...(lang === 'ar' ? { right: 14 } : { left: 14 }),
                background: 'none', border: 'none', cursor: 'pointer', padding: 4,
                color: 'rgba(255,255,255,.35)',
              }}>
                {showPw ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          {/* Confirm Password */}
          {!isLogin && (
            <>
              <div className="an-enter">
                <label style={labelStyle}>{t.conf}</label>
                <input
                  type="password"
                  value={cpw} onChange={e => setCpw(e.target.value)}
                  style={inputStyle}
                  placeholder={t.conf}
                />
              </div>
              <div className="an-enter">
                <label style={labelStyle}>{lang === 'ar' ? 'رقم الهاتف' : 'Phone number'}</label>
                <div style={{position:'relative'}}>
                  <span style={{position:'absolute',left:14,top:'50%',transform:'translateY(-50%)',color:'#D4AF37',fontFamily:'Montserrat,sans-serif',fontWeight:900,fontSize:15,pointerEvents:'none'}}>+213</span>
                  <input
                    type="tel"
                  value={phone} onChange={e => setPhone(cleanAlgerianPhoneInput(e.target.value))}
                    name="br_phone_no_autofill"
                    autoComplete="off"
                    inputMode="tel"
                    style={{ ...inputStyle, direction: 'ltr', textAlign: 'left', fontFamily: 'Montserrat, sans-serif', paddingLeft: 58 }}
                    placeholder=""
                  />
                </div>
              </div>
              <div className="an-enter">
                <label style={labelStyle}>{lang === 'ar' ? 'الولاية' : 'Wilaya'}</label>
                <button type="button" onClick={()=>setShowWilayas(true)} style={{...inputStyle,textAlign:lang==='ar'?'right':'left',cursor:'pointer',color:wilaya?'#fff':'rgba(255,255,255,.55)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
                  <span>{wilaya || (lang === 'ar' ? 'اختر ولايتك من القائمة' : 'Choose your wilaya from list')}</span>
                  <span style={{color:'#D4AF37'}}>⌄</span>
                </button>
              </div>
            </>
          )}

          {/* Submit */}
          <button type="submit" disabled={loading} style={{
            width: '100%',
            background: 'linear-gradient(135deg, #D4AF37, #C9992C, #B8860B)',
            border: 'none', borderRadius: 14,
            color: '#020509', padding: '14px 0',
            fontSize: 16, fontWeight: 900,
            cursor: loading ? 'not-allowed' : 'pointer',
            opacity: loading ? 0.6 : 1,
            boxShadow: '0 4px 20px rgba(212,175,55,.3)',
            fontFamily: 'Tajawal, sans-serif',
            marginTop: 4,
          }}>
            {loading ? '...' : (isLogin ? t.signIn : t.signUp)}
          </button>
        </form>

        {/* Toggle */}
        <button onClick={() => { setIsLogin(!isLogin); setPhone(''); setWilaya(''); setCpw(''); }} style={{
          display: 'block', margin: '16px auto 16px',
          background: 'none', border: 'none',
          color: 'rgba(255,255,255,.45)', fontSize: 13, fontWeight: 700,
          cursor: 'pointer', fontFamily: 'Tajawal, sans-serif',
        }}>
          {isLogin ? t.noAcc : t.hasAcc}
        </button>

        {/* Security box */}
        <div style={{
          background: 'linear-gradient(160deg, rgba(10,16,32,.98), rgba(7,12,24,.99))',
          border: '1px solid rgba(212,175,55,.1)',
          borderRadius: 16, padding: 16,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <Shield size={14} color="#22C55E" style={{ flexShrink: 0 }} />
            <span style={{ color: '#22C55E', fontSize: 13, fontWeight: 800 }}>Platform Security</span>
          </div>
          <p style={{ color: 'rgba(255,255,255,.35)', fontSize: 12, lineHeight: 1.8, fontWeight: 600 }}>
            • {lang === 'ar' ? 'عقد رسمي: يناير 2025 → ديسمبر 2027' : 'Contract: Jan 2025 → Dec 2027'}<br />
            • AES-256 + SSL/TLS 3.0<br />
            • NYSE: BLK — EIN: 32-0174431
          </p>
        </div>
      </div>
      {showWilayas && (
        <div className="an-fadeIn" style={{position:'fixed',inset:0,zIndex:500,background:'rgba(0,0,0,.82)',display:'flex',alignItems:'flex-end'}} onClick={e=>{if(e.currentTarget===e.target)setShowWilayas(false)}}>
          <div className="an-slideUp no-sb touch-scroll" style={{width:'100%',maxHeight:'78vh',overflowY:'auto',background:'linear-gradient(180deg,#0b1122,#050912)',borderRadius:'22px 22px 0 0',borderTop:'1px solid rgba(212,175,55,.18)',padding:'14px 14px 34px'}}>
            <div style={{width:38,height:4,borderRadius:2,background:'rgba(212,175,55,.22)',margin:'0 auto 12px'}} />
            <h3 style={{textAlign:'center',color:'#fff',fontSize:18,fontWeight:900,marginBottom:12}}>{lang==='ar'?'اختر ولايتك':'Choose your wilaya'}</h3>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
              {WILAYAS.map(w=>(
                <button key={w} type="button" onClick={()=>{setWilaya(w);setShowWilayas(false)}} style={{background:wilaya===w?'linear-gradient(135deg,#D4AF37,#C9992C)':'rgba(255,255,255,.04)',border:wilaya===w?'none':'1px solid rgba(255,255,255,.07)',borderRadius:12,padding:'11px 8px',color:wilaya===w?'#020509':'#fff',fontFamily:'Tajawal,sans-serif',fontSize:13,fontWeight:900,cursor:'pointer'}}>{w}</button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
