import { useState } from 'react';
import { useStore } from '../store';
import { T, WP } from '../utils';
import { X } from 'lucide-react';

export function Wheel() {
  const { user, lang, wheelRot, setWheelRot, toast2, updUser, setShowWheel } = useStore();
  const t = T[lang];
  const [spinning, setSpinning] = useState(false);
  const [prizeRec, setPrizeRec] = useState<{l:string;v:number}|null>(null);
  if (!user) return null;

  const doSpin = () => {
    if (spinning || (user.wheelSpins||0) <= 0) return;
    setSpinning(true); setPrizeRec(null);
    const n=WP.length, seg=360/n, add=1440+Math.random()*1440, nr=wheelRot+add;
    setWheelRot(nr);
    setTimeout(() => {
      const wi=Math.floor(((360-(nr%360))+(seg/2))%360/seg)%n;
      const prize=WP[wi]; setSpinning(false);
      const ns=Math.max(0,(user.wheelSpins||0)-1);
      if (prize.v>0) { updUser({balance:(user.balance||0)+prize.v,totalEarned:(user.totalEarned||0)+prize.v,wheelSpins:ns}); toast2(`🎉 +${prize.v} د.ج!`,'success'); }
      else { updUser({wheelSpins:ns+1}); toast2(lang==='ar'?'🎠 دورة إضافية!':'🎠 Extra spin!','warning'); }
      setPrizeRec(prize);
    }, 4100);
  };

  const cx=134,cy=134,r=128,n=WP.length,seg=360/n;
  return (
    <div className="an-fadeIn" style={{position:'fixed',inset:0,background:'rgba(0,0,0,.95)',zIndex:300,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:20,color:'#fff'}}>
      <button onClick={()=>setShowWheel(false)} style={{position:'absolute',top:48,right:16,width:36,height:36,background:'rgba(255,255,255,.06)',border:'1px solid rgba(255,255,255,.06)',borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer',color:'rgba(255,255,255,.45)'}}><X size={16} /></button>
      <div style={{textAlign:'center',marginBottom:16}}>
        <p className="font-mon" style={{fontSize:11,fontWeight:800,color:'#D4AF37',letterSpacing:2}}>{t.wheel.toUpperCase()}</p>
        <p style={{color:'rgba(255,255,255,.3)',fontSize:12,marginTop:4}}>{lang==='ar'?'دوراتك':'Spins'}: <span style={{color:'#D4AF37',fontWeight:800}}>{user.wheelSpins||0}</span></p>
      </div>
      <div style={{position:'relative',marginBottom:20}}>
        <div style={{position:'absolute',top:-12,left:'50%',transform:'translateX(-50%)',borderLeft:'11px solid transparent',borderRight:'11px solid transparent',borderTop:'22px solid #EF4444',zIndex:10,filter:'drop-shadow(0 0 5px rgba(239,68,68,.6))'}} />
        <svg width="268" height="268" viewBox="0 0 268 268" style={{borderRadius:'50%',boxShadow:'0 0 40px rgba(212,175,55,.2)',transform:`rotate(${wheelRot}deg)`,transition:spinning?'transform 4s cubic-bezier(.17,.67,.12,.99)':'none'}}>
          {WP.map((p,i)=>{const a1=(i*seg-90)*Math.PI/180,a2=((i+1)*seg-90)*Math.PI/180;const x1=(cx+r*Math.cos(a1)).toFixed(1),y1=(cy+r*Math.sin(a1)).toFixed(1),x2=(cx+r*Math.cos(a2)).toFixed(1),y2=(cy+r*Math.sin(a2)).toFixed(1),mx=(cx+(r*.62)*Math.cos((a1+a2)/2)).toFixed(1),my=(cy+(r*.62)*Math.sin((a1+a2)/2)).toFixed(1),rot=(i*seg+(seg/2)-90).toFixed(1);return(<g key={i}><path d={`M${cx},${cy} L${x1},${y1} A${r},${r} 0 0,1 ${x2},${y2} Z`} fill={p.cl} stroke="rgba(0,0,0,.35)" strokeWidth="1"/><text x={mx} y={my} textAnchor="middle" dominantBaseline="middle" fontFamily="Montserrat,sans-serif" fontWeight="900" fontSize="10.5" fill="#fff" transform={`rotate(${rot},${mx},${my})`}>{p.l}</text></g>)})}
          <circle cx={cx} cy={cy} r="25" fill="#020509" stroke="#D4AF37" strokeWidth="3"/><text x={cx} y={cy} textAnchor="middle" dominantBaseline="middle" fontFamily="Montserrat,sans-serif" fontSize="11" fontWeight="900" fill="#D4AF37">BLK</text>
        </svg>
      </div>
      <div style={{minHeight:50,display:'flex',alignItems:'center',justifyContent:'center',marginBottom:12,width:'100%',maxWidth:275}}>
        {prizeRec && <div className="bg-shim an-enter" style={{border:'1px solid rgba(212,175,55,.1)',borderRadius:16,padding:'10px 18px',textAlign:'center',width:'100%'}}>
          <p className="font-mon" style={{color:'rgba(255,255,255,.3)',fontSize:9,marginBottom:2}}>{t.prize}</p>
          <p className="font-mon tg" style={{fontSize:22,fontWeight:900}}>{prizeRec.v>0?`+${prizeRec.v} د.ج`:prizeRec.l}</p>
        </div>}
      </div>
      <button onClick={doSpin} disabled={spinning||(user.wheelSpins||0)<=0} className="bg-gold" style={{width:'100%',maxWidth:275,border:'none',color:'#020509',borderRadius:12,padding:'14px 0',fontSize:15,fontWeight:800,cursor:spinning||(user.wheelSpins||0)<=0?'not-allowed':'pointer',opacity:spinning||(user.wheelSpins||0)<=0?.5:1}}>
        {spinning?'🎡':((user.wheelSpins||0)>0?`🎯 ${t.spin}`:t.noSpin)}
      </button>
      <p style={{color:'rgba(255,255,255,.25)',fontSize:9,marginTop:8,textAlign:'center',fontWeight:700}}>{t.ef}</p>
    </div>
  );
}
