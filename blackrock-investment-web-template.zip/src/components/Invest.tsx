import { useState } from 'react';
import { useStore, type Investment } from '../store';
import { fmt } from '../utils';
import { X, Shield, TrendingUp, Clock, DollarSign, ChevronDown, ChevronUp, CheckCircle, Wallet } from 'lucide-react';

const FUNDS = [
  { id:1, ar:'صندوق الطاقة المتجددة', en:'Renewable Energy Fund',
    dAr:'استثمر في مشاريع الطاقة الشمسية والرياح مع عوائد مضمونة',
    dEn:'Invest in solar and wind projects with guaranteed returns',
    days:15, daily:6.5, total:97.5, min:1000, max:Number.MAX_SAFE_INTEGER, sold:72, hot:true, emoji:'⚡' },
  { id:2, ar:'صندوق استثمار الذهب', en:'Gold Investment Fund',
    dAr:'استثمار آمن في الذهب مع عوائد يومية ثابتة',
    dEn:'Safe gold investment with fixed daily returns',
    days:30, daily:4.2, total:126, min:1000, max:Number.MAX_SAFE_INTEGER, sold:85, hot:false, emoji:'🪙' },
  { id:3, ar:'صندوق التكنولوجيا', en:'Global Tech Fund',
    dAr:'استثمر في شركات التقنية الكبرى مع عوائد عالية',
    dEn:'Invest in top tech companies with high returns',
    days:10, daily:8.0, total:80, min:1000, max:Number.MAX_SAFE_INTEGER, sold:54, hot:true, emoji:'💻' },
  { id:4, ar:'صندوق العقارات', en:'Real Estate Fund',
    dAr:'عقارات فاخرة مع عوائد شهرية مستقرة',
    dEn:'Luxury properties with stable monthly returns',
    days:60, daily:2.8, total:168, min:1000, max:Number.MAX_SAFE_INTEGER, sold:38, hot:false, emoji:'🏢' },
  { id:5, ar:'صندوق VIP حصري', en:'VIP Exclusive Fund',
    dAr:'للمستثمرين المميزين فقط مع أعلى العوائد',
    dEn:'Premium investors only with highest returns',
    days:7, daily:12.0, total:84, min:1000, max:Number.MAX_SAFE_INTEGER, sold:91, hot:true, emoji:'💎' },
];

export function Invest() {
  const { lang, setShowInvest, user, toast2, updUser, setSheet, closeSheet } = useStore();
  const ar = lang === 'ar';
  const [openId, setOpenId] = useState<number|null>(null);
  const [amounts, setAmounts] = useState<Record<number,string>>({});
  const [viewTab, setViewTab] = useState<'funds'|'my'>('funds');
  const colors = ['#22C55E','#D4AF37','#3B82F6','#A855F7','#F59E0B'];

  const myInvestments = user?.investments || [];
  const totalInvested = myInvestments.reduce((s,inv) => s + inv.amount, 0);
  const totalEarnedFromInvest = user?.investEarned || 0;

  const handleBuy = (fund: typeof FUNDS[0]) => {
    if (!user) return;
    const amtStr = amounts[fund.id] || '';
    const amt = parseFloat(amtStr);
    if (!amt || amt < fund.min) {
      toast2(ar ? `الحد الأدنى ${fmt(fund.min)} د.ج` : `Minimum ${fmt(fund.min)} د.ج`, 'warning');
      return;
    }
    if (amt > (user.balance || 0)) {
      toast2(ar ? 'رصيد غير كافي' : 'Insufficient balance', 'error');
      return;
    }

    // Confirm purchase
    setSheet(
      <div style={{textAlign:'center',padding:'8px 0'}}>
        <div style={{fontSize:48,marginBottom:12}}>{fund.emoji}</div>
        <p style={{color:'#fff',fontWeight:900,fontSize:18,marginBottom:4}}>{ar ? fund.ar : fund.en}</p>
        <p style={{color:'rgba(255,255,255,.4)',fontSize:14,marginBottom:16}}>{ar ? 'تأكيد الاستثمار' : 'Confirm Investment'}</p>
        
        <div style={{background:'rgba(255,255,255,.03)',borderRadius:14,padding:14,marginBottom:16,textAlign:'right'}}>
          {[
            [ar?'المبلغ':'Amount', fmt(amt)+' د.ج'],
            [ar?'المدة':'Duration', fund.days+' '+(ar?'يوم':'days')],
            [ar?'العائد اليومي':'Daily Return', fund.daily+'%'],
            [ar?'الربح اليومي':'Daily Profit', fmt(amt * fund.daily / 100)+' د.ج'],
            [ar?'إجمالي الربح':'Total Profit', fmt(amt * fund.total / 100)+' د.ج'],
          ].map((r,i)=>(
            <div key={i} style={{display:'flex',justifyContent:'space-between',padding:'8px 0',borderBottom:i<4?'1px solid rgba(255,255,255,.04)':'none'}}>
              <span style={{color:'rgba(255,255,255,.4)',fontSize:14,fontWeight:700}}>{r[0]}</span>
              <span style={{color:'#fff',fontSize:14,fontWeight:800}}>{r[1]}</span>
            </div>
          ))}
        </div>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
          <button onClick={closeSheet} style={{background:'rgba(255,255,255,.05)',border:'1px solid rgba(255,255,255,.08)',color:'#fff',borderRadius:14,padding:'14px 0',fontSize:15,fontWeight:800,cursor:'pointer',fontFamily:'Tajawal,sans-serif'}}>
            {ar?'إلغاء':'Cancel'}
          </button>
          <button onClick={() => {
            const newInv: Investment = {
              id: Date.now(),
              fundId: fund.id,
              amount: amt,
              date: new Date().toISOString(),
              days: fund.days,
              daily: fund.daily,
              status: 'active',
              earned: 0,
            };
            const newInvestments = [...(user.investments||[]), newInv];
            const newNotif = { id: Date.now(), title: '📈 '+(ar?'استثمار جديد':'New Investment'), desc: (ar?fund.ar:fund.en)+' — '+fmt(amt)+' د.ج', t: new Date().toLocaleTimeString(), r: false };
            updUser({
              balance: (user.balance||0) - amt,
              investments: newInvestments,
              notifs: [...(user.notifs||[]), newNotif],
            });
            closeSheet();
            setAmounts(prev => ({...prev, [fund.id]: ''}));
            toast2(ar ? '✅ تم الاستثمار بنجاح!' : '✅ Investment successful!', 'success');
          }} style={{background:'linear-gradient(135deg,#22C55E,#16A34A)',border:'none',color:'#fff',borderRadius:14,padding:'14px 0',fontSize:15,fontWeight:800,cursor:'pointer',fontFamily:'Tajawal,sans-serif'}}>
            {ar?'تأكيد ✅':'Confirm ✅'}
          </button>
        </div>
      </div>,
      ar ? 'تأكيد الاستثمار' : 'Confirm Investment'
    );
  };

  const getDaysLeft = (inv: Investment) => {
    const start = new Date(inv.date).getTime();
    const now = Date.now();
    const passed = Math.floor((now - start) / 86400000);
    return Math.max(0, inv.days - passed);
  };

  const getDailyEarned = (inv: Investment) => {
    const start = new Date(inv.date).getTime();
    const now = Date.now();
    const passed = Math.min(Math.floor((now - start) / 86400000), inv.days);
    return inv.amount * inv.daily / 100 * passed;
  };

  return (
    <div className="an-fadeIn" style={{position:'fixed',inset:0,background:'#020509',zIndex:300,display:'flex',flexDirection:'column'}}>
      {/* Header */}
      <div style={{flexShrink:0,display:'flex',alignItems:'center',justifyContent:'space-between',padding:'12px 16px',borderBottom:'1px solid rgba(212,175,55,.1)',background:'rgba(2,5,9,.97)'}}>
        <div style={{width:40,height:40,background:'linear-gradient(135deg,#D4AF37,#C9992C)',borderRadius:12,display:'flex',alignItems:'center',justifyContent:'center'}}>
          <TrendingUp size={20} color="#020509" />
        </div>
        <div style={{textAlign:'center'}}>
          <p style={{fontSize:17,fontWeight:900,color:'#D4AF37'}}>{ar?'استثمار BlackRock':'BlackRock Invest'}</p>
          <p style={{color:'rgba(255,255,255,.35)',fontSize:12,fontWeight:700}}>{ar?'صناديق استثمارية مضمونة':'Guaranteed Funds'}</p>
        </div>
        <button onClick={()=>setShowInvest(false)} style={{width:40,height:40,background:'rgba(255,255,255,.04)',border:'1px solid rgba(255,255,255,.08)',borderRadius:12,display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer',color:'rgba(255,255,255,.5)'}}>
          <X size={18} />
        </button>
      </div>

      {/* Tab Switch */}
      <div style={{display:'flex',gap:0,padding:'0 16px',borderBottom:'1px solid rgba(255,255,255,.04)',flexShrink:0}}>
        {[{id:'funds' as const,l:ar?'الصناديق':'Funds'},{id:'my' as const,l:ar?'استثماراتي':'My Investments'}].map(tb=>(
          <button key={tb.id} onClick={()=>setViewTab(tb.id)} style={{
            flex:1,padding:'12px 0',background:'none',border:'none',cursor:'pointer',
            fontSize:14,fontWeight:800,fontFamily:'Tajawal,sans-serif',
            color:viewTab===tb.id?'#D4AF37':'rgba(255,255,255,.35)',
            borderBottom:viewTab===tb.id?'2px solid #D4AF37':'2px solid transparent',
          }}>{tb.l} {tb.id==='my' && myInvestments.length>0 ? `(${myInvestments.length})` : ''}</button>
        ))}
      </div>

      {/* Content */}
      <div className="no-sb touch-scroll" style={{flex:1,overflowY:'auto',overflowX:'hidden'}}>
        <div style={{padding:'12px 16px 60px',display:'flex',flexDirection:'column',gap:12}}>

          {viewTab === 'funds' ? <>
            {/* Safety */}
            <div style={{background:'linear-gradient(135deg,rgba(34,197,94,.06),rgba(34,197,94,.02))',border:'1px solid rgba(34,197,94,.22)',borderRadius:14,padding:14,display:'flex',alignItems:'center',gap:10}}>
              <Shield size={20} color="#22C55E" style={{flexShrink:0}} />
              <p style={{color:'#22C55E',fontSize:15,fontWeight:800}}>{ar?'الأموال آمنة ومأمنة ✅':'Funds Safe & Secure ✅'}</p>
            </div>

            {/* Balance */}
            <div style={{background:'linear-gradient(160deg,rgba(12,18,36,.98),rgba(8,13,26,.99))',border:'1px solid rgba(212,175,55,.15)',borderRadius:16,padding:18}}>
              <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:14}}>
                <Wallet size={18} color="#D4AF37" />
                <p style={{color:'rgba(255,255,255,.5)',fontSize:13,fontWeight:700}}>{ar?'رصيدك المتاح':'Available Balance'}</p>
              </div>
              <p style={{fontFamily:'Montserrat,sans-serif',fontSize:30,fontWeight:900,color:'#D4AF37',textAlign:'center'}}>{fmt(user?.balance||0)} <span style={{fontSize:14,color:'rgba(255,255,255,.3)'}}>د.ج</span></p>
            </div>

            {/* Fund Cards */}
            {FUNDS.map((fund,idx) => {
              const isOpen = openId === fund.id;
              const color = colors[idx % colors.length];
              const amtVal = amounts[fund.id] || '';

              return (
                <div key={fund.id} style={{background:'linear-gradient(160deg,rgba(10,16,32,.98),rgba(7,12,24,.99))',border:isOpen?`1px solid ${color}55`:'1px solid rgba(255,255,255,.06)',borderRadius:16,overflow:'hidden'}}>
                  {/* Header Row */}
                  <div onClick={()=>setOpenId(isOpen?null:fund.id)} style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:16,cursor:'pointer',gap:10}}>
                    <div style={{display:'flex',alignItems:'center',gap:12,flex:1,minWidth:0}}>
                      <div style={{fontSize:30,lineHeight:1,flexShrink:0}}>{fund.emoji}</div>
                      <div style={{minWidth:0}}>
                        <p style={{color:'#fff',fontWeight:800,fontSize:16,marginBottom:3,wordBreak:'break-word'}}>{ar?fund.ar:fund.en}</p>
                        <p style={{color:'rgba(255,255,255,.4)',fontSize:13,fontWeight:700}}>
                          <span style={{color}}>{fund.daily}%</span> {ar?'يومياً':'daily'} · {fund.days} {ar?'يوم':'days'}
                        </p>
                      </div>
                    </div>
                    <div style={{display:'flex',alignItems:'center',gap:6,flexShrink:0}}>
                      {fund.hot && <span style={{background:'#EF4444',borderRadius:6,padding:'2px 8px',fontSize:10,fontWeight:800,color:'#fff',whiteSpace:'nowrap'}}>🔥</span>}
                      {isOpen?<ChevronUp size={20} color="rgba(255,255,255,.3)"/>:<ChevronDown size={20} color="rgba(255,255,255,.3)"/>}
                    </div>
                  </div>

                  {isOpen && (
                    <div className="an-enter" style={{padding:'0 16px 16px'}}>
                      <p style={{color:'rgba(255,255,255,.5)',fontSize:14,lineHeight:1.8,marginBottom:14}}>{ar?fund.dAr:fund.dEn}</p>

                      {/* Stats */}
                      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:8,marginBottom:14}}>
                        {[
                          {icon:Clock,label:ar?'المدة':'Duration',value:String(fund.days),sub:ar?'يوم':'Days',clr:color},
                          {icon:TrendingUp,label:ar?'يومي':'Daily',value:fund.daily+'%',sub:ar?'عائد':'Return',clr:'#22C55E'},
                          {icon:DollarSign,label:ar?'إجمالي':'Total',value:fund.total+'%',sub:ar?'عودة':'Return',clr:'#D4AF37'},
                        ].map((st,si)=>(
                          <div key={si} style={{background:'rgba(255,255,255,.03)',borderRadius:12,padding:'12px 6px',textAlign:'center'}}>
                            <div style={{display:'flex',alignItems:'center',justifyContent:'center',gap:4,marginBottom:6}}>
                              <st.icon size={13} color={st.clr} />
                              <span style={{color:'rgba(255,255,255,.4)',fontSize:11,fontWeight:700}}>{st.label}</span>
                            </div>
                            <p style={{fontFamily:'Montserrat,sans-serif',fontSize:22,fontWeight:900,color:st.clr,lineHeight:1}}>{st.value}</p>
                            <p style={{color:'rgba(255,255,255,.3)',fontSize:10,fontWeight:600,marginTop:4}}>{st.sub}</p>
                          </div>
                        ))}
                      </div>

                      {/* Progress */}
                      <div style={{marginBottom:14}}>
                        <div style={{display:'flex',justifyContent:'space-between',marginBottom:6}}>
                          <span style={{color:'rgba(255,255,255,.5)',fontSize:13,fontWeight:700}}>{fund.sold}%</span>
                          <span style={{color:'rgba(255,255,255,.3)',fontSize:12,fontWeight:600}}>{ar?'تم البيع':'Sold'}</span>
                        </div>
                        <div style={{background:'rgba(255,255,255,.06)',borderRadius:5,height:8,overflow:'hidden'}}>
                          <div style={{height:'100%',borderRadius:5,background:`linear-gradient(90deg,${color},${color}AA)`,width:`${fund.sold}%`}} />
                        </div>
                      </div>

                      {/* Buy Limit */}
                      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'10px 14px',marginBottom:12,background:'rgba(255,255,255,.02)',borderRadius:12,border:'1px solid rgba(255,255,255,.05)'}}>
                        <span style={{color:'rgba(255,255,255,.45)',fontSize:13,fontWeight:700}}>{ar?'حد الشراء':'Buy Limit'}</span>
                        <span style={{fontFamily:'Montserrat,sans-serif',color:'rgba(255,255,255,.6)',fontSize:12,fontWeight:700,direction:'ltr'}}>{fmt(fund.min)} د.ج ~ {ar ? 'حسب رصيدك' : 'your balance'}</span>
                      </div>

                      {/* Amount Input */}
                      <div style={{marginBottom:12}}>
                        <label style={{display:'block',color:'rgba(255,255,255,.5)',fontSize:13,fontWeight:700,marginBottom:6}}>{ar?'مبلغ الاستثمار (د.ج)':'Investment Amount (د.ج)'}</label>
                        <div style={{position:'relative'}}>
                          <input
                            type="number"
                            value={amtVal}
                            onChange={e => setAmounts(prev => ({...prev, [fund.id]: e.target.value}))}
                            placeholder={fmt(fund.min)}
                            style={{width:'100%',background:'rgba(255,255,255,.04)',border:'1px solid rgba(255,255,255,.1)',borderRadius:14,color:'#fff',padding:'14px 16px',fontSize:16,fontWeight:700,outline:'none',fontFamily:'Montserrat,sans-serif'}}
                          />
                          {amtVal && parseFloat(amtVal) >= fund.min && (
                            <div style={{marginTop:8,background:'rgba(34,197,94,.06)',borderRadius:10,padding:'8px 12px',display:'flex',justifyContent:'space-between'}}>
                              <span style={{color:'rgba(255,255,255,.4)',fontSize:12,fontWeight:700}}>{ar?'الربح اليومي المتوقع':'Expected Daily Profit'}</span>
                              <span style={{color:'#22C55E',fontSize:13,fontWeight:800,fontFamily:'Montserrat,sans-serif'}}>+{fmt(parseFloat(amtVal)*fund.daily/100)} د.ج</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Quick amounts */}
                      <div style={{display:'flex',gap:6,marginBottom:14,flexWrap:'wrap'}}>
                        {[fund.min, fund.min*5, fund.min*10, fund.min*50, user?.balance || 0].filter((v,i,a)=>v>=fund.min && v <= (user?.balance||0) && a.indexOf(v)===i).map((v,i)=>(
                          <button key={i} onClick={()=>setAmounts(prev=>({...prev,[fund.id]:String(v)}))} style={{
                            padding:'6px 12px',background:'rgba(255,255,255,.04)',border:'1px solid rgba(255,255,255,.08)',
                            borderRadius:10,color:'rgba(255,255,255,.5)',fontSize:12,fontWeight:700,cursor:'pointer',fontFamily:'Montserrat,sans-serif',
                          }}>{fmt(v)}</button>
                        ))}
                      </div>

                      {/* Buy Button */}
                      <button onClick={()=>handleBuy(fund)} style={{
                        width:'100%',background:`linear-gradient(135deg,${color},${color}CC)`,
                        border:'none',borderRadius:14,color:'#020509',padding:'15px 0',
                        fontSize:17,fontWeight:900,cursor:'pointer',fontFamily:'Tajawal,sans-serif',
                        boxShadow:`0 4px 16px ${color}33`,
                      }}>
                        {ar?'اشتري الآن 🚀':'Buy Now 🚀'}
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </> : <>
            {/* My Investments Tab */}
            {myInvestments.length === 0 ? (
              <div style={{textAlign:'center',padding:'40px 0'}}>
                <div style={{fontSize:48,marginBottom:12}}>📭</div>
                <p style={{color:'rgba(255,255,255,.4)',fontSize:16,fontWeight:800}}>{ar?'لا توجد استثمارات بعد':'No investments yet'}</p>
                <p style={{color:'rgba(255,255,255,.25)',fontSize:13,marginTop:4}}>{ar?'اختر صندوقاً واستثمر الآن':'Choose a fund and invest now'}</p>
                <button onClick={()=>setViewTab('funds')} style={{marginTop:16,background:'linear-gradient(135deg,#D4AF37,#C9992C)',border:'none',borderRadius:12,color:'#020509',padding:'12px 24px',fontSize:15,fontWeight:800,cursor:'pointer',fontFamily:'Tajawal,sans-serif'}}>
                  {ar?'تصفح الصناديق':'Browse Funds'}
                </button>
              </div>
            ) : <>
              {/* Summary */}
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
                <div style={{background:'linear-gradient(160deg,rgba(10,16,32,.98),rgba(7,12,24,.99))',border:'1px solid rgba(212,175,55,.12)',borderRadius:14,padding:16,textAlign:'center'}}>
                  <p style={{color:'rgba(255,255,255,.4)',fontSize:12,fontWeight:700,marginBottom:6}}>{ar?'إجمالي المستثمر':'Total Invested'}</p>
                  <p style={{fontFamily:'Montserrat,sans-serif',fontSize:18,fontWeight:900,color:'#D4AF37'}}>{fmt(totalInvested)}</p>
                  <p style={{color:'rgba(255,255,255,.25)',fontSize:10,marginTop:2}}>د.ج</p>
                </div>
                <div style={{background:'linear-gradient(160deg,rgba(10,16,32,.98),rgba(7,12,24,.99))',border:'1px solid rgba(34,197,94,.12)',borderRadius:14,padding:16,textAlign:'center'}}>
                  <p style={{color:'rgba(255,255,255,.4)',fontSize:12,fontWeight:700,marginBottom:6}}>{ar?'إجمالي الأرباح':'Total Earned'}</p>
                  <p style={{fontFamily:'Montserrat,sans-serif',fontSize:18,fontWeight:900,color:'#22C55E'}}>{fmt(totalEarnedFromInvest)}</p>
                  <p style={{color:'rgba(255,255,255,.25)',fontSize:10,marginTop:2}}>د.ج</p>
                </div>
              </div>

              {/* Investment List */}
              {myInvestments.map(inv => {
                const fund = FUNDS.find(f=>f.id===inv.fundId);
                if (!fund) return null;
                const daysLeft = getDaysLeft(inv);
                const earned = getDailyEarned(inv);
                const progress = Math.min(100, ((inv.days - daysLeft) / inv.days) * 100);
                const isComplete = daysLeft <= 0;
                const color = colors[(fund.id-1) % colors.length];

                return (
                  <div key={inv.id} style={{background:'linear-gradient(160deg,rgba(10,16,32,.98),rgba(7,12,24,.99))',border:`1px solid ${isComplete?'rgba(34,197,94,.2)':'rgba(255,255,255,.06)'}`,borderRadius:16,padding:16}}>
                    <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:12}}>
                      <span style={{fontSize:28}}>{fund.emoji}</span>
                      <div style={{flex:1}}>
                        <p style={{color:'#fff',fontWeight:800,fontSize:15}}>{ar?fund.ar:fund.en}</p>
                        <p style={{color:'rgba(255,255,255,.35)',fontSize:12,fontWeight:600}}>{new Date(inv.date).toLocaleDateString()}</p>
                      </div>
                      {isComplete ? (
                        <span style={{background:'rgba(34,197,94,.1)',border:'1px solid rgba(34,197,94,.2)',borderRadius:8,padding:'4px 10px',display:'flex',alignItems:'center',gap:4}}>
                          <CheckCircle size={12} color="#22C55E" />
                          <span style={{color:'#22C55E',fontSize:11,fontWeight:800}}>{ar?'مكتمل':'Done'}</span>
                        </span>
                      ) : (
                        <span style={{background:'rgba(59,130,246,.08)',border:'1px solid rgba(59,130,246,.18)',borderRadius:8,padding:'4px 10px',color:'#3B82F6',fontSize:11,fontWeight:800}}>
                          {daysLeft} {ar?'يوم':'days'}
                        </span>
                      )}
                    </div>

                    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:6,marginBottom:12}}>
                      <div style={{background:'rgba(255,255,255,.03)',borderRadius:10,padding:'8px 6px',textAlign:'center'}}>
                        <p style={{color:'rgba(255,255,255,.35)',fontSize:10,fontWeight:600,marginBottom:2}}>{ar?'المبلغ':'Amount'}</p>
                        <p style={{fontFamily:'Montserrat,sans-serif',color:'#D4AF37',fontSize:13,fontWeight:800}}>{fmt(inv.amount)}</p>
                      </div>
                      <div style={{background:'rgba(255,255,255,.03)',borderRadius:10,padding:'8px 6px',textAlign:'center'}}>
                        <p style={{color:'rgba(255,255,255,.35)',fontSize:10,fontWeight:600,marginBottom:2}}>{ar?'العائد':'Return'}</p>
                        <p style={{fontFamily:'Montserrat,sans-serif',color:'#22C55E',fontSize:13,fontWeight:800}}>+{fmt(earned)}</p>
                      </div>
                      <div style={{background:'rgba(255,255,255,.03)',borderRadius:10,padding:'8px 6px',textAlign:'center'}}>
                        <p style={{color:'rgba(255,255,255,.35)',fontSize:10,fontWeight:600,marginBottom:2}}>{ar?'يومي':'Daily'}</p>
                        <p style={{fontFamily:'Montserrat,sans-serif',color,fontSize:13,fontWeight:800}}>{inv.daily}%</p>
                      </div>
                    </div>

                    <div style={{background:'rgba(255,255,255,.06)',borderRadius:4,height:6,overflow:'hidden'}}>
                      <div style={{height:'100%',borderRadius:4,background:isComplete?'linear-gradient(90deg,#22C55E,#4ADE80)':`linear-gradient(90deg,${color},${color}AA)`,width:`${progress}%`}} />
                    </div>
                    <div style={{display:'flex',justifyContent:'space-between',marginTop:4}}>
                      <span style={{color:'rgba(255,255,255,.3)',fontSize:10,fontWeight:600}}>{Math.round(progress)}%</span>
                      <span style={{color:'rgba(255,255,255,.25)',fontSize:10,fontWeight:600}}>{inv.days - daysLeft}/{inv.days} {ar?'يوم':'days'}</span>
                    </div>
                  </div>
                );
              })}
            </>}
          </>}

          {/* Disclaimer */}
          <div style={{background:'rgba(255,255,255,.02)',border:'1px solid rgba(255,255,255,.05)',borderRadius:14,padding:14,textAlign:'center'}}>
            <p style={{color:'rgba(255,255,255,.25)',fontSize:12,lineHeight:1.9}}>
              {ar?'⚠️ جميع الاستثمارات محمية بعقد رسمي مع BlackRock. العوائد تقديرية.':'⚠️ All investments protected by official BlackRock contract.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
