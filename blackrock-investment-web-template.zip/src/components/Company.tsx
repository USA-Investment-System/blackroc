import { useStore } from '../store';
import { T } from '../utils';
import { ArrowRight, Shield, Globe, Building, Users, TrendingUp, Lock, FileText } from 'lucide-react';

export function Company() {
  const { lang, setShowCompany } = useStore();
  const t = T[lang];
  const ar = lang === 'ar';

  return (
    <div className="an-fadeIn" style={{position:'fixed',inset:0,background:'#020509',zIndex:300,display:'flex',flexDirection:'column'}}>
      <div style={{flexShrink:0,display:'flex',alignItems:'center',justifyContent:'space-between',padding:'12px 16px',borderBottom:'1px solid rgba(212,175,55,.08)',background:'rgba(2,5,9,.97)'}}>
        <button onClick={()=>setShowCompany(false)} style={{width:36,height:36,background:'rgba(255,255,255,.04)',border:'1px solid rgba(255,255,255,.06)',borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer',color:'rgba(255,255,255,.45)'}}>
          <ArrowRight size={16} style={{transform:ar?'none':'rotate(180deg)'}} />
        </button>
        <div style={{textAlign:'center'}}>
          <p className="font-mon" style={{fontSize:13,fontWeight:900,letterSpacing:2,color:'#D4AF37'}}>BLACKROCK</p>
          <p style={{color:'rgba(255,255,255,.25)',fontSize:8,letterSpacing:1,fontWeight:700}}>COMPANY PROFILE</p>
        </div>
        <div className="bg-gold" style={{width:36,height:36,borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center'}}><Building size={16} color="#020509" /></div>
      </div>

      <div className="no-sb touch-scroll" style={{flex:1,overflowY:'auto',padding:'12px 16px 48px',display:'flex',flexDirection:'column',gap:10}}>
        {/* Hero */}
        <div className="bg-shim" style={{border:'1px solid rgba(212,175,55,.12)',borderRadius:20,padding:'24px 16px',textAlign:'center',position:'relative',overflow:'hidden'}}>
          <div style={{position:'absolute',top:0,left:0,right:0,height:100,background:'radial-gradient(ellipse at 50% -30%,rgba(212,175,55,.05),transparent 70%)'}} />
          <div style={{position:'relative'}}>
            <div className="bg-gold an-glow" style={{width:68,height:68,borderRadius:18,display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 12px'}}><Building size={30} color="#020509" /></div>
            <h2 className="font-mon tg" style={{fontSize:22,fontWeight:900,letterSpacing:3,marginBottom:4}}>BLACKROCK</h2>
            <p style={{color:'rgba(255,255,255,.3)',fontSize:11,fontWeight:700,letterSpacing:1}}>BlackRock, Inc — New York, USA</p>
            <div style={{display:'flex',alignItems:'center',justifyContent:'center',gap:6,marginTop:10,flexWrap:'wrap'}}>
              <span style={{background:'rgba(34,197,94,.06)',border:'1px solid rgba(34,197,94,.15)',borderRadius:99,padding:'2px 10px',color:'#22C55E',fontSize:9,fontWeight:800,display:'inline-flex',alignItems:'center',gap:3}}><Shield size={9} /> {ar?'موثقة':'Verified'}</span>
              <span style={{background:'rgba(212,175,55,.06)',border:'1px solid rgba(212,175,55,.12)',borderRadius:99,padding:'2px 10px',color:'#D4AF37',fontSize:9,fontWeight:800}}>NYSE: BLK</span>
            </div>
          </div>
        </div>

        {/* About */}
        <div className="bg-card" style={{border:'1px solid rgba(255,255,255,.04)',borderRadius:16,padding:14}}>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8}}>
            <div style={{width:32,height:32,background:'rgba(59,130,246,.06)',borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}><Globe size={15} style={{color:'#3B82F6'}} /></div>
            <p style={{color:'#fff',fontWeight:800,fontSize:14}}>{t.aboutT}</p>
          </div>
          <p style={{color:'rgba(255,255,255,.45)',fontSize:13,lineHeight:1.9}}>{t.coDesc}</p>
        </div>

        {/* Stats */}
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:6}}>
          {[
            {v:'1988',l:ar?'سنة التأسيس':'Founded',ic:Building,c:'#D4AF37',bg:'rgba(212,175,55,.05)'},
            {v:'$10.2T',l:ar?'الأصول المدارة':'AUM',ic:TrendingUp,c:'#22C55E',bg:'rgba(34,197,94,.05)'},
            {v:'+19,000',l:ar?'الموظفين':'Employees',ic:Users,c:'#3B82F6',bg:'rgba(59,130,246,.05)'},
            {v:'38',l:ar?'دولة':'Nations',ic:Globe,c:'#A855F7',bg:'rgba(168,85,247,.05)'},
          ].map((s,i)=>(
            <div key={i} className="bg-card" style={{border:'1px solid rgba(255,255,255,.04)',borderRadius:16,padding:12,textAlign:'center'}}>
              <div style={{width:32,height:32,background:s.bg,borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 6px'}}><s.ic size={15} style={{color:s.c}} /></div>
              <p className="font-mon" style={{fontSize:16,fontWeight:900,color:s.c}}>{s.v}</p>
              <p style={{color:'rgba(255,255,255,.3)',fontSize:10,fontWeight:700,marginTop:2}}>{s.l}</p>
            </div>
          ))}
        </div>

        {/* Security */}
        <div className="bg-card" style={{border:'1px solid rgba(34,197,94,.12)',borderRadius:16,padding:14}}>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8}}>
            <div style={{width:32,height:32,background:'rgba(34,197,94,.06)',borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}><Shield size={15} style={{color:'#22C55E'}} /></div>
            <p style={{color:'#fff',fontWeight:800,fontSize:14}}>{t.secT}</p>
          </div>
          <p style={{color:'rgba(255,255,255,.45)',fontSize:13,lineHeight:1.9,marginBottom:10}}>{t.coSec}</p>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:6}}>
            {[{v:'AES-256',l:ar?'تشفير عسكري':'Military Encryption'},{v:'SSL/TLS 3.0',l:ar?'بروتوكول آمن':'Secure Protocol'},{v:'100%',l:ar?'حماية الأموال':'Fund Protection'},{v:'24/7',l:ar?'مراقبة مستمرة':'Monitoring'}].map((s,i)=>(
              <div key={i} style={{background:'rgba(255,255,255,.02)',border:'1px solid rgba(255,255,255,.03)',borderRadius:10,padding:8,textAlign:'center'}}>
                <p className="font-mon" style={{color:'#22C55E',fontSize:11,fontWeight:800}}>{s.v}</p>
                <p style={{color:'rgba(255,255,255,.25)',fontSize:9,fontWeight:700,marginTop:1}}>{s.l}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Algeria Contract */}
        <div className="bg-card" style={{border:'1px solid rgba(212,175,55,.12)',borderRadius:16,padding:14}}>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8}}>
            <div style={{width:32,height:32,background:'rgba(212,175,55,.06)',borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}><FileText size={15} style={{color:'#D4AF37'}} /></div>
            <p style={{color:'#fff',fontWeight:800,fontSize:14}}>🇩🇿 {ar?'العقد الجزائري':'Algeria Contract'}</p>
          </div>
          <p style={{color:'rgba(255,255,255,.45)',fontSize:13,lineHeight:1.9,marginBottom:10}}>{t.coAlg}</p>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:6}}>
            {[{v:'Jan 2025',l:ar?'البداية':'Start',c:'#22C55E'},{v:'Dec 2027',l:ar?'النهاية':'End',c:'#D4AF37'},{v:'3 '+(ar?'سنوات':'Years'),l:ar?'المدة':'Duration',c:'#3B82F6'}].map((s,i)=>(
              <div key={i} style={{background:'rgba(255,255,255,.02)',border:'1px solid rgba(255,255,255,.03)',borderRadius:10,padding:8,textAlign:'center'}}>
                <p className="font-mon" style={{fontSize:11,fontWeight:800,color:s.c}}>{s.v}</p>
                <p style={{color:'rgba(255,255,255,.2)',fontSize:9,fontWeight:700,marginTop:1}}>{s.l}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Contract Text */}
        <div className="bg-shim" style={{border:'1px solid rgba(212,175,55,.08)',borderRadius:16,padding:16}}>
          <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:8}}><Lock size={12} style={{color:'#D4AF37'}} /><span style={{color:'#D4AF37',fontSize:10,fontWeight:800,letterSpacing:1}}>{ar?'النص الرسمي للعقد':'OFFICIAL CONTRACT'}</span></div>
          <p style={{color:'rgba(255,255,255,.55)',fontSize:13,lineHeight:2}}>{t.contract}</p>
        </div>

        {/* Registration */}
        <div className="bg-card" style={{border:'1px solid rgba(255,255,255,.04)',borderRadius:16,padding:14}}>
          <p style={{color:'#fff',fontWeight:800,fontSize:14,marginBottom:8}}>{ar?'معلومات التسجيل':'Registration Info'}</p>
          {[['NYSE: BLK',ar?'رمز التداول':'Stock Symbol'],['EIN: 32-0174431',ar?'الرقم الضريبي':'Tax ID'],['New York, USA',ar?'المقر الرئيسي':'Headquarters'],['Larry Fink',ar?'الرئيس التنفيذي':'CEO'],['blackrock.com',ar?'الموقع الرسمي':'Website']].map((r,i)=>(
            <div key={i} style={{display:'flex',justifyContent:'space-between',padding:'8px 0',borderBottom:i<4?'1px solid rgba(255,255,255,.03)':'none'}}>
              <span style={{color:'rgba(255,255,255,.3)',fontSize:12,fontWeight:700}}>{r[1]}</span>
              <span style={{color:'#fff',fontWeight:800,fontSize:12}}>{r[0]}</span>
            </div>
          ))}
        </div>

        <button onClick={()=>window.open('https://www.blackrock.com','_blank')} className="bg-gold" style={{width:'100%',border:'none',color:'#020509',borderRadius:16,padding:'14px 0',fontSize:14,fontWeight:800,display:'flex',alignItems:'center',justifyContent:'center',gap:8,cursor:'pointer'}}>
          <Globe size={16} /> blackrock.com
        </button>
      </div>
    </div>
  );
}
