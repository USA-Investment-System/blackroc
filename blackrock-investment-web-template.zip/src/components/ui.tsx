import { useEffect, useState } from 'react';
import { useStore } from '../store';
import { Home as HI, Zap, Diamond, User as UI } from 'lucide-react';
import { T } from '../utils';

export function Nav() {
  const { tab, setTab, tasks, user, lang } = useStore();
  const t = T[lang];
  const avail = tasks ? tasks.filter(x => x.status === 'available').length : 5;
  const unread = user?.notifs?.filter(n => !n.r).length || 0;
  const tabs: { id: 'home' | 'tasks' | 'up' | 'profile'; ic: typeof HI; l: string; b: number }[] = [
    { id: 'home', ic: HI, l: t.home, b: 0 },
    { id: 'tasks', ic: Zap, l: t.tasks, b: avail },
    { id: 'up', ic: Diamond, l: t.up, b: 0 },
    { id: 'profile', ic: UI, l: t.acc, b: unread },
  ];

  return (
    <nav style={{
      position: 'absolute', bottom: 0, left: 0, right: 0, height: 68,
      background: 'rgba(2,5,9,.97)',
      borderTop: '1px solid rgba(212,175,55,.1)',
      display: 'flex', zIndex: 50,
    }}>
      {tabs.map(tb => {
        const on = tab === tb.id;
        return (
          <button key={tb.id} onClick={() => setTab(tb.id)} style={{
            flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
            gap: 3, background: 'none', border: 'none', cursor: 'pointer',
            color: on ? '#D4AF37' : 'rgba(255,255,255,.3)',
            position: 'relative', transition: 'color .2s',
            fontFamily: 'Tajawal, sans-serif',
          }}>
            {on && <div style={{
              position: 'absolute', top: 0, left: '50%', transform: 'translateX(-50%)',
              width: 28, height: 3, borderRadius: '0 0 2px 2px',
              background: 'linear-gradient(135deg, #D4AF37, #C9992C)',
            }} />}
            <div style={{ position: 'relative' }}>
              <tb.ic size={22} strokeWidth={on ? 2.5 : 1.8} />
              {tb.b > 0 && <span style={{
                position: 'absolute', top: -5, right: -8,
                minWidth: 16, height: 16, background: '#EF4444',
                borderRadius: 8, border: '1.5px solid #020509',
                fontSize: 8, fontWeight: 900, color: '#fff',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                padding: '0 3px',
              }}>{tb.b}</span>}
            </div>
            <span style={{ fontSize: 10, fontWeight: on ? 800 : 600, opacity: on ? 1 : 0.7 }}>{tb.l}</span>
          </button>
        );
      })}
    </nav>
  );
}

export function Toast() {
  const { toast } = useStore();
  useEffect(() => {
    if (!toast) return;
    const tm = setTimeout(() => useStore.setState({ toast: null }), 2800);
    return () => clearTimeout(tm);
  }, [toast]);
  if (!toast) return null;
  const c: Record<string, string> = { success: '#16A34A', error: '#DC2626', warning: '#D97706', info: '#1E40AF' };
  return (
    <div className="an-enter" style={{
      position: 'fixed', top: 20, left: '50%', transform: 'translateX(-50%)',
      zIndex: 9999, padding: '10px 20px', borderRadius: 99,
      fontSize: 13, fontWeight: 800, color: '#fff',
      whiteSpace: 'nowrap', maxWidth: '88vw',
      overflow: 'hidden', textOverflow: 'ellipsis',
      background: c[toast.type] || c.info,
      boxShadow: '0 8px 30px rgba(0,0,0,.5)',
    }}>
      {toast.msg}
    </div>
  );
}

export function SaveBadge() {
  const pulse = useStore(s => s.savePulse);
  const lang = useStore(s => s.lang);
  const [show, setShow] = useState(false);
  useEffect(() => {
    if (!pulse) return;
    setShow(true);
    const t = setTimeout(() => setShow(false), 1200);
    return () => clearTimeout(t);
  }, [pulse]);
  if (!show) return null;
  return (
    <div className="an-enter" style={{position:'fixed',top:14,right:14,zIndex:9998,display:'flex',alignItems:'center',gap:6,background:'rgba(34,197,94,.12)',border:'1px solid rgba(34,197,94,.25)',borderRadius:99,padding:'6px 10px',color:'#22C55E',fontSize:11,fontWeight:900,backdropFilter:'blur(8px)'}}>
      <span style={{width:7,height:7,borderRadius:4,background:'#22C55E',display:'inline-block'}} />
      {lang === 'ar' ? 'تم الحفظ' : 'Saved'}
    </div>
  );
}

export function Sheet() {
  const { sheet, closeSheet } = useStore();
  if (!sheet) return null;
  return (
    <div className="an-fadeIn" style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,.85)',
      zIndex: 200, display: 'flex', alignItems: 'flex-end',
    }} onClick={e => { if (e.target === e.currentTarget) closeSheet(); }}>
      <div className="an-slideUp no-sb touch-scroll" style={{
        background: 'linear-gradient(180deg, #0b1122, #050912)',
        borderRadius: '22px 22px 0 0',
        borderTop: '1px solid rgba(212,175,55,.12)',
        width: '100%', maxHeight: '90vh', overflowY: 'auto',
      }}>
        <div style={{ width: 36, height: 4, background: 'rgba(212,175,55,.18)', borderRadius: 2, margin: '12px auto 8px' }} />
        {sheet.title && <div style={{
          textAlign: 'center', fontSize: 15, fontWeight: 800, color: '#fff',
          padding: '0 16px 12px',
          borderBottom: '1px solid rgba(255,255,255,.05)',
        }}>{sheet.title}</div>}
        <div style={{ padding: '16px 16px 48px' }}>{sheet.content}</div>
      </div>
    </div>
  );
}
