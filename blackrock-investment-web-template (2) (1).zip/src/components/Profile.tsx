import { useEffect, useState } from 'react';
import { useStore } from '../store';
import { T, fmt, lvN, fDZD } from '../utils';
import { Shield, Users, Gift, Settings, LogOut, Globe, X, Trophy, Building, ChevronLeft, Camera, Activity, UserPlus, CheckCircle } from 'lucide-react';

const AVATAR_STYLES = [
  { id: 'avataaars', label: 'Avataaars' },
  { id: 'lorelei', label: 'Lorelei' },
  { id: 'micah', label: 'Micah' },
  { id: 'adventurer', label: 'Adventurer' },
  { id: 'notionists', label: 'Notion' },
];
const AVATAR_SEEDS = ['Ahmed', 'Amina', 'Yacine', 'Sofia', 'Karim', 'Lina', 'Nassim', 'Rania', 'Samir', 'Nour', 'Zaki', 'Meriem'];
const avatarUrl = (style: string, seed: string) =>
  `https://api.dicebear.com/7.x/${style}/svg?seed=${encodeURIComponent(seed)}&backgroundColor=0f172a,1e293b,312e81`;
const FIRST_NAMES = ['أحمد','محمد','ياسين','كريم','سمير','نسيم','وليد','يوسف','أمين','أنيس','إلياس','رياض','سفيان','بلال','مهدي','عادل','فارس','إسلام','أسامة','حمزة','زكي','ريان','عبد النور','نور الدين','مصطفى','مراد','جمال','حكيم','طارق','سليم','نبيل','رؤوف','أيمن','إدريس','هشام','منير','عمر','إسماعيل','مالك','إسحاق','أحلام','أمينة','صوفيا','لينا','رانيا','مريم','إيمان','نور','سارة','ياسمين','إكرام','آية','هاجر','خديجة','وسام','نسرين','شيماء','منى','لامية','أسماء','سمية','دعاء','هدى','كوثر','نادية','ريم','سلمى','إيناس','نهال','أميرة','بسمة','مليكة','فاطمة','زهرة','حياة','سعاد','جميلة','ليلى','رانية','حنان','نوال','فيروز'];
const FAMILY_NAMES = ['بن خالد','بن علي','منصوري','بوضياف','آيت أحمد','حداد','خليفي','سعيدي','براهيمي','زروال','بلقاسم','حمادي','بوعزيز','عمراني','فرحات','دحماني','قرفي','مقراني','لونيس','مزيان','شريف','بلعيد','قاسي','بوزيد','حمدي','صحراوي','بن سالم','برابح','طالب','بوعلام','قاسمي','رحماني','زيتوني','عباسي','بوخاري','مداني','بن يوسف','بن عمر','مهداوي','بوعكاز','غربي','درار','مباركي','سحنون','عيشاوي','بوساحة','خروبي','علوان','مسعودي','طاهري'];
const LATIN_FIRST = ['Ahmed','Mohamed','Yacine','Karim','Samir','Nassim','Walid','Youcef','Amine','Ilyes','Riad','Sofiane','Bilal','Mehdi','Adel','Fares','Hamza','Rayan','Ahlam','Amina','Sofia','Lina','Rania','Meriem','Imane','Nour','Sara','Yasmine','Ikram','Aya','Hadjer','Khadija','Wissam','Nesrine','Chaima','Mouna','Lamia','Asma','Douaa','Houda','Kawther','Nadia','Rym','Salma','Ines','Nihal'];
const LATIN_FAMILY = ['Benkhaled','Benali','Mansouri','Boudiaf','Ait Ahmed','Haddad','Khelifi','Saidi','Brahimi','Zeroual','Belkacem','Hammadi','Bouaziz','Amrani','Ferhat','Dahmani','Guerfi','Mokrani','Lounis','Meziane','Cherif','Belaid','Kaci','Bouzid','Hamdi','Sahraoui','Bensalem','Berrabah','Taleb','Boualem','Kasmi','Rahmani','Zitouni','Abbassi','Boukhari','Madani'];
const WILAYA_NAMES = ['أدرار','الشلف','الأغواط','أم البواقي','باتنة','بجاية','بسكرة','بشار','البليدة','البويرة','تمنراست','تبسة','تلمسان','تيارت','تيزي وزو','الجزائر','الجلفة','جيجل','سطيف','سعيدة','سكيكدة','سيدي بلعباس','عنابة','قالمة','قسنطينة','المدية','مستغانم','المسيلة','معسكر','ورقلة','وهران','البيض','إليزي','برج بوعريريج','بومرداس','الطارف','تندوف','تيسمسيلت','الوادي','خنشلة','سوق أهراس','تيبازة','ميلة','عين الدفلى','النعامة','عين تموشنت','غرداية','غليزان','تيميمون','برج باجي مختار','أولاد جلال','بني عباس','عين صالح','عين قزام','توقرت','جانت','المغير','المنيعة'];
const LATIN_WILAYAS = ['Adrar','Chlef','Laghouat','Oum El Bouaghi','Batna','Bejaia','Biskra','Bechar','Blida','Bouira','Tamanrasset','Tebessa','Tlemcen','Tiaret','Tizi Ouzou','Alger','Djelfa','Jijel','Setif','Saida','Skikda','Sidi Bel Abbes','Annaba','Guelma','Constantine','Medea','Mostaganem','Msila','Mascara','Ouargla','Oran','El Bayadh','Illizi','Bordj Bou Arreridj','Boumerdes','El Tarf','Tindouf','Tissemsilt','El Oued','Khenchela','Souk Ahras','Tipaza','Mila','Ain Defla','Naama','Ain Temouchent','Ghardaia','Relizane','Timimoun','Bordj Badji Mokhtar','Ouled Djellal','Beni Abbes','In Salah','In Guezzam','Touggourt','Djanet','El Mghair','El Meniaa'];
const randomAlgerianName = () => {
  const latin = Math.random() < 0.45;
  const first = latin ? LATIN_FIRST[Math.floor(Math.random()*LATIN_FIRST.length)] : FIRST_NAMES[Math.floor(Math.random()*FIRST_NAMES.length)];
  const family = latin ? LATIN_FAMILY[Math.floor(Math.random()*LATIN_FAMILY.length)] : FAMILY_NAMES[Math.floor(Math.random()*FAMILY_NAMES.length)];
  const wilaya = latin ? LATIN_WILAYAS[Math.floor(Math.random()*LATIN_WILAYAS.length)] : WILAYA_NAMES[Math.floor(Math.random()*WILAYA_NAMES.length)];
  return `${first} ${family} • ${wilaya}`;
};
const getTimeBasedCount = () => {
  const h = new Date().getHours();
  if (h >= 1 && h < 6) return 420 + Math.floor(Math.random() * 780);
  if (h >= 6 && h < 10) return 950 + Math.floor(Math.random() * 1150);
  if (h >= 10 && h < 17) return 1800 + Math.floor(Math.random() * 1900);
  if (h >= 17 && h < 23) return 2400 + Math.floor(Math.random() * 2400);
  return 900 + Math.floor(Math.random() * 1300);
};

function AvatarPicker({ current, username, lang }: { current: string | null; username: string; lang: string }) {
  const { updUser, toast2, closeSheet } = useStore();
  const [style, setStyle] = useState('avataaars');
  const [selected, setSelected] = useState<string | null>(current);
  const ar = lang === 'ar';
  const save = () => {
    updUser({ avatar: selected });
    closeSheet();
    toast2(ar ? 'تم حفظ الصورة' : 'Avatar saved', 'success');
  };
  return (
    <div style={{display:'flex',flexDirection:'column',gap:14}}>
      <div style={{textAlign:'center'}}>
        <p style={{color:'#fff',fontWeight:900,fontSize:20,marginBottom:4}}>✨ {ar?'اختر صورتك':'Choose your avatar'}</p>
        <p style={{color:'rgba(255,255,255,.38)',fontSize:13,fontWeight:700}}>{ar?'صور مولدة بالذكاء الاصطناعي':'AI generated avatar styles'}</p>
      </div>
      <div className="no-sb" style={{display:'flex',gap:8,overflowX:'auto',paddingBottom:2}}>
        {AVATAR_STYLES.map(s=>(
          <button key={s.id} onClick={()=>setStyle(s.id)} className={style===s.id?'bg-gold':''} style={{border:style===s.id?'none':'1px solid rgba(255,255,255,.08)',background:style===s.id?undefined:'rgba(255,255,255,.04)',borderRadius:99,padding:'8px 16px',color:style===s.id?'#020509':'rgba(255,255,255,.6)',fontSize:13,fontWeight:900,cursor:'pointer',whiteSpace:'nowrap'}}>{s.label}</button>
        ))}
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:10}}>
        {AVATAR_SEEDS.slice(0,6).map(seed=>{
          const src = avatarUrl(style, seed);
          const on = selected === src;
          return <button key={src} onClick={()=>setSelected(src)} style={{position:'relative',padding:0,border:on?'2px solid #D4AF37':'1px solid rgba(255,255,255,.08)',borderRadius:18,overflow:'hidden',background:'rgba(255,255,255,.04)',cursor:'pointer',aspectRatio:'1/1'}}>
            <img src={src} alt={seed} style={{width:'100%',height:'100%',objectFit:'cover',display:'block'}} loading="lazy" />
            {on && <span style={{position:'absolute',top:8,right:8,width:22,height:22,borderRadius:11,background:'#22C55E',display:'flex',alignItems:'center',justifyContent:'center'}}><CheckCircle size={14} color="#fff"/></span>}
          </button>
        })}
      </div>
      <button onClick={()=>setSelected(null)} style={{display:'flex',alignItems:'center',justifyContent:'space-between',background:'rgba(212,175,55,.08)',border:'1px solid rgba(212,175,55,.2)',borderRadius:16,padding:14,cursor:'pointer'}}>
        <span style={{color:'#fff',fontSize:14,fontWeight:900}}>{ar?'الحرف الافتراضي':'Default letter'}</span>
        <span className="bg-gold" style={{width:44,height:44,borderRadius:22,display:'flex',alignItems:'center',justifyContent:'center',color:'#020509',fontWeight:900,fontSize:18}}>{username[0]?.toUpperCase()}</span>
      </button>
      <button onClick={save} className="bg-gold" style={{border:'none',borderRadius:16,padding:'15px 0',color:'#020509',fontSize:17,fontWeight:900,cursor:'pointer',fontFamily:'Tajawal,sans-serif'}}>✓ {ar?'حفظ الصورة':'Save avatar'}</button>
    </div>
  );
}

export function Profile() {
  const { user, lang, toggleLang, toast2, setSheet, logout, setShowCompany, setShowWheel, updUser } = useStore();
  const t = T[lang];
  const [live, setLive] = useState(() => ({
    count: getTimeBasedCount(),
    name: randomAlgerianName(),
  }));
  useEffect(() => {
    let alive = true;
    const run = () => {
      if (!alive) return;
      setLive({
        count: getTimeBasedCount(),
        name: randomAlgerianName(),
      });
      window.setTimeout(run, 1800 + Math.floor(Math.random() * 2600));
    };
    run();
    return () => { alive = false; };
  }, []);
  if (!user) return null;
  const cpRef = () => { navigator.clipboard.writeText(user.ref).catch(() => {}); toast2(t.copied, 'success'); };
  const shareRef = () => {
    const msg = `🏦 BlackRock\n${user.ref}\n💰 ${lang === 'ar' ? 'اربح يومياً!' : 'Earn daily!'}`;
    if (navigator.share) navigator.share({ title: 'BlackRock', text: msg, url: user.ref }).catch(() => {});
    else { navigator.clipboard.writeText(msg).catch(() => {}); toast2(t.copied, 'success'); }
  };
  const prog = (user.m1Refs || 0) % 10;
  const pickAvatar = () => setSheet(<AvatarPicker current={user.avatar} username={user.un} lang={lang} />, lang==='ar'?'اختر صورة الحساب':'Choose Avatar');

  const openSecSh = () => setSheet(<div style={{display:'flex',flexDirection:'column',gap:6}}>
    <div className="bg-card" style={{border:'1px solid rgba(212,175,55,.08)',borderRadius:16,padding:14,textAlign:'center'}}><div style={{fontSize:28,marginBottom:4}}>🛡️</div><p style={{color:'#fff',fontWeight:800,fontSize:14}}>{t.secT}</p></div>
    {[['NYSE: BLK','Registration'],['EIN: 32-0174431','Tax ID'],['AES-256 + SSL/TLS 3.0','Encryption'],['January 2025 ✅','Algeria Contract'],['December 2027','Contract End'],['100% Protected ✅','Fund Security']].map((r,i)=>(
      <div key={i} className="bg-card" style={{border:'1px solid rgba(255,255,255,.04)',borderRadius:10,padding:10,display:'flex',justifyContent:'space-between',alignItems:'center'}}><span style={{color:'rgba(255,255,255,.35)',fontSize:12,fontWeight:700}}>{r[1]}</span><span style={{color:'#fff',fontWeight:800,fontSize:12}}>{r[0]}</span></div>
    ))}
    <div className="bg-card" style={{border:'1px solid rgba(212,175,55,.08)',borderRadius:10,padding:12,marginTop:4}}><p style={{color:'rgba(255,255,255,.6)',fontSize:12,lineHeight:1.8,textAlign:'center'}}>{t.contract}</p></div>
  </div>, t.secT);

  const openRefSh = () => setSheet(<div style={{display:'flex',flexDirection:'column',gap:10}}>
    <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
      <div className="bg-card" style={{border:'1px solid rgba(212,175,55,.1)',borderRadius:16,padding:14,textAlign:'center'}}><p className="font-mon" style={{color:'#D4AF37',fontSize:24,fontWeight:900}}>{user.teamCount||0}</p><p style={{color:'rgba(255,255,255,.35)',fontSize:11,fontWeight:700,marginTop:2}}>{t.totRef}</p></div>
      <div className="bg-card" style={{border:'1px solid rgba(34,197,94,.15)',borderRadius:16,padding:14,textAlign:'center'}}><p className="font-mon" style={{color:'#22C55E',fontSize:16,fontWeight:900}}>{fmt(user.refEarn||0)} د.ج</p><p style={{color:'rgba(255,255,255,.35)',fontSize:11,fontWeight:700,marginTop:2}}>{t.refDzd}</p></div>
    </div>
    <div className="bg-card" style={{border:'1px solid rgba(168,85,247,.18)',borderRadius:16,padding:14}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:8}}><span style={{color:'#fff',fontSize:14,fontWeight:900}}>🏆 {lang==='ar'?'مسابقة الدعوة':'Referral Contest'}</span><span style={{color:'#A855F7',fontWeight:900}}>{(user.m1Refs||0)%10}/10</span></div>
      <div style={{height:6,background:'rgba(255,255,255,.07)',borderRadius:4,overflow:'hidden'}}><div style={{height:'100%',width:`${((user.m1Refs||0)%10)*10}%`,background:'linear-gradient(90deg,#A855F7,#D4AF37)',borderRadius:4}} /></div>
      <p style={{color:'rgba(255,255,255,.38)',fontSize:12,lineHeight:1.8,marginTop:8}}>{lang==='ar'?'كل صديق يسجل برابطك = دورة عجلة حظ لك وله. عند 10 أصدقاء M1 تحصل على ترقية مجانية.':'Each friend joining with your link gives both of you a lucky spin. 10 M1 friends unlock a free upgrade.'}</p>
    </div>
    <div className="bg-card" style={{border:'1px solid rgba(212,175,55,.1)',borderRadius:16,padding:14}}>
      <p style={{color:'#fff',fontWeight:800,fontSize:13,textAlign:'center',marginBottom:10}}>🔗 {lang==='ar'?'رابط الدعوة':'Your referral link'}</p>
      <div style={{background:'rgba(255,255,255,.03)',border:'1px solid rgba(255,255,255,.05)',borderRadius:10,padding:10,color:'rgba(255,255,255,.55)',fontSize:11,marginBottom:10,wordBreak:'break-all',direction:'ltr'}}>{user.ref}</div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
        <button onClick={cpRef} className="bg-gold" style={{border:'none',borderRadius:12,padding:'12px 0',color:'#020509',fontSize:13,fontWeight:900,cursor:'pointer'}}>نسخ</button>
        <button onClick={shareRef} style={{background:'rgba(255,255,255,.06)',border:'1px solid rgba(255,255,255,.08)',borderRadius:12,padding:'12px 0',color:'#fff',fontSize:13,fontWeight:900,cursor:'pointer'}}>مشاركة</button>
      </div>
    </div>
    <div className="bg-card" style={{border:'1px solid rgba(255,255,255,.06)',borderRadius:16,padding:14}}>
      <p style={{color:'#fff',fontWeight:900,fontSize:14,marginBottom:10}}>👥 {lang==='ar'?'أعضاء الفريق':'Team Members'}</p>
      {(user.team||[]).length === 0 ? <p style={{color:'rgba(255,255,255,.35)',fontSize:12,lineHeight:1.8}}>{lang==='ar'?'لم ينضم أي صديق بعد. شارك رابطك وابدأ بناء فريقك.':'No friends joined yet. Share your link and start building your team.'}</p> :
        (user.team||[]).slice().reverse().map(m=>(
          <div key={m.id} style={{display:'flex',alignItems:'center',gap:10,padding:'9px 0',borderBottom:'1px solid rgba(255,255,255,.04)'}}>
            {m.avatar ? <img src={m.avatar} alt="" style={{width:34,height:34,borderRadius:12,objectFit:'cover'}}/> : <div className="bg-gold" style={{width:34,height:34,borderRadius:12,display:'flex',alignItems:'center',justifyContent:'center',color:'#020509',fontWeight:900}}>{m.username[0]?.toUpperCase()}</div>}
            <div style={{flex:1,minWidth:0}}><p style={{color:'#fff',fontWeight:800,fontSize:12}}>{m.username}</p><p style={{color:'rgba(255,255,255,.3)',fontSize:10}}>BLK-{m.code}</p></div>
            <span style={{color:m.active?'#22C55E':'#F59E0B',fontSize:10,fontWeight:800}}>{m.active?(lang==='ar'?'نشط':'Active'):(lang==='ar'?'جديد':'New')}</span>
          </div>
        ))}
    </div>
  </div>, t.refsT);

  const openSetSh = () => {
    let phoneVal = user.phone || '';
    let wilayaVal = user.wilaya || '';
    setSheet(<div style={{display:'flex',flexDirection:'column',gap:8}}>
    <div className="bg-card" style={{border:'1px solid rgba(212,175,55,.08)',borderRadius:16,padding:12}}>
      {[[lang==='ar'?'اسم المستخدم':'Username',user.un],[lang==='ar'?'الرصيد':'Balance',fmt(user.balance||0)+' د.ج'],[lang==='ar'?'المستوى':'Level',lvN(user.level)],[lang==='ar'?'الإحالات':'Referrals',String(user.teamCount||0)]].map((r,i)=>(
        <div key={i} style={{display:'flex',justifyContent:'space-between',padding:'8px 0',borderBottom:i<3?'1px solid rgba(255,255,255,.04)':'none'}}><span style={{color:'rgba(255,255,255,.3)',fontSize:12,fontWeight:700}}>{r[0]}</span><span style={{color:'#fff',fontSize:12,fontWeight:800}}>{r[1]}</span></div>
      ))}
    </div>
    <div className="bg-card" style={{border:'1px solid rgba(255,255,255,.06)',borderRadius:16,padding:12,display:'flex',flexDirection:'column',gap:10}}>
      {[[lang==='ar'?'رقم الهاتف':'Phone number', phoneVal || (lang==='ar'?'غير محدد':'Not set')],[lang==='ar'?'الولاية / الموقع':'Wilaya / Location', wilayaVal || (lang==='ar'?'غير محددة':'Not set')]].map((r,i)=>(
        <div key={i} style={{display:'flex',justifyContent:'space-between',alignItems:'center',gap:10,padding:'9px 0',borderBottom:i===0?'1px solid rgba(255,255,255,.04)':'none'}}>
          <span style={{color:'rgba(255,255,255,.42)',fontSize:12,fontWeight:800}}>{r[0]}</span>
          <span style={{color:'#fff',fontSize:13,fontWeight:900,direction:i===0?'ltr':undefined}}>{r[1]}</span>
        </div>
      ))}
      <p style={{color:'rgba(255,255,255,.32)',fontSize:11,lineHeight:1.8,fontWeight:700}}>
        {lang==='ar'?'لا يمكن تغيير رقم الهاتف أو الولاية بعد إنشاء الحساب. إذا كانت المعلومات خاطئة يجب إنشاء حساب جديد بمعلومات صحيحة.':'Phone and wilaya cannot be changed after account creation. Create a new account if the information is wrong.'}
      </p>
    </div>
    <button onClick={()=>{updUser({showLiveActivity:user.showLiveActivity===false}); useStore.getState().closeSheet(); toast2(user.showLiveActivity===false?(lang==='ar'?'تم إظهارك في النشطين':'You are visible in live list'):(lang==='ar'?'تم إخفاء ظهورك فقط':'Only your visibility was hidden'),'success');}} style={{width:'100%',background:user.showLiveActivity===false?'rgba(34,197,94,.08)':'rgba(239,68,68,.07)',border:user.showLiveActivity===false?'1px solid rgba(34,197,94,.18)':'1px solid rgba(239,68,68,.16)',color:user.showLiveActivity===false?'#22C55E':'#EF4444',borderRadius:12,padding:'12px 0',fontSize:13,fontWeight:800,display:'flex',alignItems:'center',justifyContent:'center',gap:8,cursor:'pointer'}}>
      {user.showLiveActivity===false?'✅':'❌'} {user.showLiveActivity===false?(lang==='ar'?'إظهار ظهوري في النشطين':'Show my live status'):(lang==='ar'?'إخفاء ظهوري من النشطين':'Hide my live status')}
    </button>
    <button onClick={toggleLang} style={{width:'100%',background:'rgba(255,255,255,.04)',border:'1px solid rgba(255,255,255,.06)',color:'#fff',borderRadius:12,padding:'12px 0',fontSize:13,fontWeight:800,display:'flex',alignItems:'center',justifyContent:'center',gap:8,cursor:'pointer'}}><Globe size={15} /> {lang==='ar'?'Switch to English':'التبديل للعربية'}</button>
    <button onClick={()=>{if(confirm(lang==='ar'?'مسح كل البيانات؟':'Clear all data?')){localStorage.clear();location.reload();}}} style={{width:'100%',background:'rgba(239,68,68,.06)',border:'1px solid rgba(239,68,68,.12)',color:'#EF4444',borderRadius:12,padding:'12px 0',fontSize:13,fontWeight:800,display:'flex',alignItems:'center',justifyContent:'center',gap:8,cursor:'pointer'}}><X size={15} /> {t.clear}</button>
  </div>, t.setT);
  };

  const tryWheel = () => { useStore.getState().closeSheet(); if ((user.wheelSpins||0)<=0){toast2(lang==='ar'?'ادعُ صديقاً!':'Invite a friend!','warning');return;} setShowWheel(true); };

  const openActivity = () => setSheet(
    <div style={{display:'flex',flexDirection:'column',gap:10}}>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
        <div className="bg-card" style={{border:'1px solid rgba(59,130,246,.14)',borderRadius:16,padding:14,textAlign:'center'}}><p className="font-mon" style={{color:'#3B82F6',fontSize:22,fontWeight:900}}>{user.loginStreak||0}</p><p style={{color:'rgba(255,255,255,.35)',fontSize:11,fontWeight:700}}>🔥 {lang==='ar'?'حضور متتالي':'Login streak'}</p></div>
        <div className="bg-card" style={{border:'1px solid rgba(20,184,166,.14)',borderRadius:16,padding:14,textAlign:'center'}}><p className="font-mon" style={{color:'#14B8A6',fontSize:22,fontWeight:900}}>{(user.investments||[]).length}</p><p style={{color:'rgba(255,255,255,.35)',fontSize:11,fontWeight:700}}>📈 {lang==='ar'?'استثمارات':'Investments'}</p></div>
      </div>
      <div className="bg-card" style={{border:'1px solid rgba(255,255,255,.06)',borderRadius:16,padding:14}}>
        <p style={{color:'#fff',fontWeight:900,fontSize:14,marginBottom:10}}>📋 {lang==='ar'?'سجل النشاطات':'Activity Log'}</p>
        {(user.activityLog||[]).length === 0 ? <p style={{color:'rgba(255,255,255,.35)',fontSize:12}}>{lang==='ar'?'لا توجد نشاطات بعد':'No activity yet'}</p> :
          (user.activityLog||[]).slice().reverse().slice(0,12).map((item,i)=>(
            <div key={i} style={{padding:'9px 0',borderBottom:i<Math.min((user.activityLog||[]).length,12)-1?'1px solid rgba(255,255,255,.04)':'none',display:'flex',gap:8,alignItems:'center'}}>
              <span style={{width:7,height:7,borderRadius:4,background:'#D4AF37',flexShrink:0}} />
              <p style={{color:'rgba(255,255,255,.55)',fontSize:11,lineHeight:1.6}}>{item}</p>
            </div>
          ))}
      </div>
    </div>,
    lang==='ar'?'نشاطاتي':'My Activity'
  );

  const achievementItems = [
    { id:'first_task', icon:'✅', title:lang==='ar'?'البداية':'The Start', desc:lang==='ar'?'أكمل أول مهمة':'Complete your first task', reward:15, unlocked:(user.taskBal||0)>0 },
    { id:'first_ref', icon:'🤝', title:lang==='ar'?'أول إحالة':'First Referral', desc:lang==='ar'?'ادعُ صديقاً واحداً':'Invite one friend', reward:30, unlocked:(user.teamCount||0)>=1 },
    { id:'small_team', icon:'👥', title:lang==='ar'?'فريق صغير':'Small Team', desc:lang==='ar'?'ادعُ 5 أصدقاء':'Invite 5 friends', reward:75, unlocked:(user.teamCount||0)>=5 },
    { id:'team_leader', icon:'🏆', title:lang==='ar'?'قائد الفريق':'Team Leader', desc:lang==='ar'?'ادعُ 10 أصدقاء':'Invite 10 friends', reward:120, unlocked:(user.teamCount||0)>=10 },
    { id:'m1_level', icon:'💎', title:lang==='ar'?'مستثمر M1':'M1 Investor', desc:lang==='ar'?'فعّل مستوى M1 أو أعلى':'Activate M1 or higher', reward:50, unlocked:!!user.level && user.level!=='trial' },
    { id:'first_invest', icon:'📈', title:lang==='ar'?'أول استثمار':'First Investment', desc:lang==='ar'?'ابدأ أول استثمار':'Start your first investment', reward:45, unlocked:(user.investments||[]).length>0 },
    { id:'streak_7', icon:'🔥', title:lang==='ar'?'سلسلة 7 أيام':'7-Day Streak', desc:lang==='ar'?'ادخل 7 أيام متتالية':'Login 7 days in a row', reward:60, unlocked:(user.loginStreak||0)>=7 },
    { id:'first_withdraw', icon:'💳', title:lang==='ar'?'أول سحب':'First Withdrawal', desc:lang==='ar'?'أرسل أول طلب سحب':'Submit your first withdrawal', reward:35, unlocked:(user.withdrawals||[]).length>0 },
  ];
  const openAchievements = () => {
    const claimed = user.badges || [];
    const completed = achievementItems.filter(a=>a.unlocked).length;
    const claim = (a: typeof achievementItems[number]) => {
      if (!a.unlocked || claimed.includes(a.id)) return;
      updUser({
        balance:(user.balance||0)+a.reward,
        totalEarned:(user.totalEarned||0)+a.reward,
        badges:[...claimed,a.id],
        notifs:[...(user.notifs||[]),{id:Date.now(),title:'🏅 '+a.title,desc:`+${a.reward} د.ج`,t:new Date().toLocaleTimeString(),r:false}],
        activityLog:[...(user.activityLog||[]).slice(-30),new Date().toLocaleString()+` - achievement ${a.id} +${a.reward} د.ج`]
      });
      useStore.getState().closeSheet();
      toast2((lang==='ar'?'تم تحصيل مكافأة ':'Reward claimed ')+`+${a.reward} د.ج`,'success');
    };
    setSheet(
      <div style={{display:'flex',flexDirection:'column',gap:10}}>
        <div className="bg-card" style={{border:'1px solid rgba(212,175,55,.16)',borderRadius:16,padding:14}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:10}}>
            <h3 style={{color:'#fff',fontSize:18,fontWeight:900}}>🏆 {lang==='ar'?'الإنجازات':'Achievements'}</h3>
            <b className="tg" style={{fontFamily:'Montserrat,sans-serif',fontSize:20}}>{completed}/{achievementItems.length}</b>
          </div>
          <div style={{height:6,background:'rgba(255,255,255,.07)',borderRadius:4,overflow:'hidden'}}>
            <div style={{height:'100%',width:`${completed/achievementItems.length*100}%`,background:'linear-gradient(90deg,#D4AF37,#22C55E)',borderRadius:4}} />
          </div>
          <p style={{color:'rgba(255,255,255,.38)',fontSize:12,lineHeight:1.7,marginTop:8}}>{lang==='ar'?'المكافآت أصبحت أخف ومتوازنة حتى تبقى الأرباح واقعية.':'Rewards are smaller and balanced for realistic earnings.'}</p>
        </div>
        {achievementItems.map(a=>{
          const isClaimed = claimed.includes(a.id);
          return <div key={a.id} className="bg-card" style={{border:`1px solid ${a.unlocked?'rgba(212,175,55,.14)':'rgba(255,255,255,.05)'}`,borderRadius:16,padding:14,display:'flex',alignItems:'center',gap:12,opacity:a.unlocked?1:.6}}>
            <span style={{fontSize:34,flexShrink:0}}>{a.icon}</span>
            <div style={{flex:1,minWidth:0}}>
              <p style={{color:'#fff',fontSize:15,fontWeight:900}}>{a.title}</p>
              <p style={{color:'rgba(255,255,255,.35)',fontSize:12,fontWeight:700,marginTop:1}}>{a.desc}</p>
              <b style={{display:'inline-block',color:'#D4AF37',fontSize:14,marginTop:6}}>+{a.reward} د.ج</b>
            </div>
            <button onClick={()=>claim(a)} disabled={!a.unlocked||isClaimed} style={{background:isClaimed?'rgba(34,197,94,.1)':a.unlocked?'linear-gradient(135deg,#D4AF37,#C9992C)':'rgba(255,255,255,.05)',border:isClaimed?'1px solid rgba(34,197,94,.18)':'1px solid rgba(255,255,255,.06)',color:isClaimed?'#22C55E':a.unlocked?'#020509':'rgba(255,255,255,.35)',borderRadius:12,padding:'9px 12px',fontSize:12,fontWeight:900,cursor:a.unlocked&&!isClaimed?'pointer':'not-allowed',fontFamily:'Tajawal,sans-serif',minWidth:78}}>{isClaimed?(lang==='ar'?'تم':'Claimed'):a.unlocked?(lang==='ar'?'تحصيل':'Claim'):(lang==='ar'?'مقفل':'Locked')}</button>
          </div>
        })}
      </div>,
      lang==='ar'?'الإنجازات':'Achievements'
    );
  };

  const menuItems = [
    {ic:Shield,l:t.secT,d:'SSL + Algeria',c:'#22C55E',fn:openSecSh},
    {ic:Building,l:t.aboutT,d:'NYSE: BLK',c:'#3B82F6',fn:()=>setShowCompany(true)},
    {ic:UserPlus,l:lang==='ar'?'دعوة الأصدقاء':'Invite Friends',d:lang==='ar'?'الفريق والتقدم':'Team and progress',c:'#D4AF37',fn:openRefSh},
    {ic:Activity,l:lang==='ar'?'نشاطاتي':'My Activity',d:lang==='ar'?'السجل والإنجازات':'Log and achievements',c:'#3B82F6',fn:openActivity},
    {ic:Trophy,l:lang==='ar'?'الإنجازات':'Achievements',d:`${achievementItems.filter(a=>a.unlocked).length}/${achievementItems.length}`,c:'#F59E0B',fn:openAchievements},
    {ic:Users,l:t.refsT,d:`${user.teamCount||0} ${lang==='ar'?'مدعو':'members'}`,c:'#D4AF37',fn:openRefSh},
    {ic:Camera,l:lang==='ar'?'صورة الحساب':'Profile Picture',d:lang==='ar'?'صور AI عشوائية':'AI avatar gallery',c:'#14B8A6',fn:pickAvatar},
    {ic:Gift,l:t.wheel,d:lang==='ar'?'مع كل صديق':'Each friend',c:'#A855F7',fn:tryWheel},
    {ic:Settings,l:t.setT,d:lang==='ar'?'الإعدادات':'Settings',c:'rgba(255,255,255,.4)',fn:openSetSh},
  ];

  return (
    <div className="an-enter" style={{paddingBottom:16}}>
      <div style={{position:'sticky',top:0,zIndex:40,background:'rgba(2,5,9,.97)',padding:'10px 16px',borderBottom:'1px solid rgba(212,175,55,.06)'}}>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between'}}>
          <div style={{display:'flex',alignItems:'center',gap:8}}>
            <div className="bg-gold" style={{width:28,height:28,borderRadius:8,display:'flex',alignItems:'center',justifyContent:'center',color:'#020509',flexShrink:0}}><Users size={15} /></div>
            <p style={{color:'#fff',fontWeight:800,fontSize:15}}>{t.myAcc}</p>
          </div>
          <button onClick={toggleLang} style={{background:'rgba(212,175,55,.06)',border:'1px solid rgba(212,175,55,.12)',borderRadius:99,padding:'2px 10px',color:'#D4AF37',fontSize:9,fontWeight:800,cursor:'pointer'}}>{t.lang}</button>
        </div>
        <div style={{marginTop:8,display:'flex',alignItems:'center',justifyContent:'center'}}>
          <div style={{display:'flex',alignItems:'center',gap:7,background:'linear-gradient(135deg,rgba(34,197,94,.09),rgba(212,175,55,.06))',border:'1px solid rgba(34,197,94,.18)',borderRadius:99,padding:'6px 12px',minWidth:220,justifyContent:'center'}}>
            <span className="an-pulse" style={{width:8,height:8,borderRadius:4,background:'#22C55E',display:'inline-block',boxShadow:'0 0 10px rgba(34,197,94,.5)'}} />
            <b className="font-mon" style={{color:'#22C55E',fontSize:12}}>{live.count.toLocaleString('fr-DZ')}</b>
            <span style={{color:'rgba(255,255,255,.72)',fontSize:11,fontWeight:800}}>{lang==='ar'?'مستخدم نشط':'active users'}</span>
            <span style={{color:'#D4AF37',fontSize:11,fontWeight:900,whiteSpace:'nowrap',maxWidth:138,overflow:'hidden',textOverflow:'ellipsis'}}>• {live.name}</span>
          </div>
        </div>
      </div>

      <div style={{padding:'12px 16px',display:'flex',flexDirection:'column',gap:10}}>
        {/* Hero */}
        <div className="bg-shim" style={{border:'1px solid rgba(212,175,55,.12)',borderRadius:20,padding:'20px 16px',textAlign:'center'}}>
          <button onClick={pickAvatar} style={{position:'relative',display:'block',width:78,height:78,margin:'0 auto 10px',border:'none',background:'none',padding:0,cursor:'pointer'}}>
            {user.avatar ? <img src={user.avatar} alt="avatar" style={{width:78,height:78,borderRadius:39,objectFit:'cover',border:'3px solid rgba(212,175,55,.85)',boxShadow:'0 0 24px rgba(212,175,55,.22)'}} /> : <div className="bg-gold" style={{width:78,height:78,borderRadius:39,display:'flex',alignItems:'center',justifyContent:'center',fontSize:30,fontWeight:900,color:'#020509'}}>{(user.un||'?')[0].toUpperCase()}</div>}
            <span className="bg-gold" style={{position:'absolute',right:0,bottom:0,width:24,height:24,borderRadius:12,display:'flex',alignItems:'center',justifyContent:'center',border:'2px solid #020509'}}><Camera size={12} color="#020509"/></span>
          </button>
          <p style={{color:'#fff',fontWeight:800,fontSize:17,marginBottom:2}}>{user.un}</p>
          <p className="font-mon" style={{color:'rgba(255,255,255,.25)',fontSize:11,fontWeight:700,marginBottom:8}}>BLK-{String(user.id).slice(-6)}</p>
          <span style={{display:'inline-block',background:'rgba(212,175,55,.08)',border:'1px solid rgba(212,175,55,.18)',borderRadius:99,padding:'2px 10px',color:'#D4AF37',fontSize:10,fontWeight:800}}>{lvN(user.level)}</span>
          {(user.phone || user.wilaya) && <div style={{marginTop:8,display:'flex',gap:6,justifyContent:'center',flexWrap:'wrap'}}>
            {user.phone && <span style={{background:'rgba(255,255,255,.04)',border:'1px solid rgba(255,255,255,.06)',borderRadius:99,padding:'2px 8px',color:'rgba(255,255,255,.45)',fontSize:10,fontWeight:800,direction:'ltr'}}>📞 {user.phone}</span>}
            {user.wilaya && <span style={{background:'rgba(255,255,255,.04)',border:'1px solid rgba(255,255,255,.06)',borderRadius:99,padding:'2px 8px',color:'rgba(255,255,255,.45)',fontSize:10,fontWeight:800}}>📍 {user.wilaya}</span>}
          </div>}
          <p style={{color:'rgba(255,255,255,.25)',fontSize:10,fontWeight:700,marginTop:8}}>{lang==='ar'?'انضم:':'Since:'} {new Date(user.joined||Date.now()).toLocaleDateString()}</p>
        </div>

        {/* Stats */}
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:6}}>
          {[{v:fmt(user.balance||0)+' د.ج',l:'💰 '+t.bal,c:'#D4AF37'},{v:String(user.teamCount||0),l:'👥 '+t.team,c:'#3B82F6'},{v:fDZD(user.totalEarned||0),l:'📈 '+t.earned,c:'#22C55E'},{v:String(user.wheelSpins||0),l:'🎡 '+t.wheel,c:'#A855F7'},{v:String(user.loginStreak||0),l:'🔥 حضور متتالي',c:'#F59E0B'},{v:String((user.investments||[]).length),l:'📈 استثمارات',c:'#14B8A6'}].map((s,i)=>(
            <div key={i} className="bg-card" style={{border:'1px solid rgba(255,255,255,.05)',borderRadius:16,padding:10,textAlign:'center'}}>
              <p className="font-mon" style={{fontSize:13,fontWeight:800,color:s.c,marginBottom:2}}>{s.v}</p>
              <p style={{color:'rgba(255,255,255,.3)',fontSize:10,fontWeight:700}}>{s.l}</p>
            </div>
          ))}
        </div>

        {/* Competition */}
        <div style={{background:'linear-gradient(135deg,rgba(168,85,247,.07),rgba(139,92,246,.03))',border:'1px solid rgba(168,85,247,.18)',borderRadius:16,padding:12}}>
          <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:6}}><Trophy size={14} style={{color:'#A855F7'}} /><span style={{color:'#fff',fontWeight:800,fontSize:13}}>{t.compT}</span></div>
          <div style={{background:'rgba(255,255,255,.06)',borderRadius:3,height:4,overflow:'hidden',marginBottom:4}}><div style={{height:'100%',background:'linear-gradient(90deg,#A855F7,#8B5CF6)',borderRadius:3,width:`${prog*10}%`}} /></div>
          <div style={{display:'flex',justifyContent:'space-between',color:'rgba(255,255,255,.25)',fontSize:9,fontWeight:700}}><span>{prog}/10</span><span>{t.goal}</span></div>
        </div>

        {/* Menu */}
        <div className="bg-card" style={{border:'1px solid rgba(212,175,55,.08)',borderRadius:16,overflow:'hidden'}}>
          {menuItems.map((m,i)=>(
            <button key={i} onClick={m.fn} style={{width:'100%',display:'flex',alignItems:'center',justifyContent:'space-between',padding:'12px 14px',background:'none',border:'none',cursor:'pointer',borderBottom:i<menuItems.length-1?'1px solid rgba(255,255,255,.03)':'none',textAlign:'right'}}>
              <div style={{display:'flex',alignItems:'center',gap:10,minWidth:0}}>
                <div style={{width:36,height:36,background:'rgba(255,255,255,.03)',borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,color:m.c}}><m.ic size={16} /></div>
                <div style={{minWidth:0}}><p style={{color:'#fff',fontWeight:800,fontSize:13,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{m.l}</p><p style={{color:'rgba(255,255,255,.25)',fontSize:10,fontWeight:700}}>{m.d}</p></div>
              </div>
              <ChevronLeft size={16} style={{color:'rgba(255,255,255,.15)',flexShrink:0,transform:lang==='ar'?'none':'rotate(180deg)'}} />
            </button>
          ))}
        </div>

        <button onClick={()=>{logout();toast2(lang==='ar'?'تم الخروج':'Signed out','success');}} style={{width:'100%',background:'rgba(239,68,68,.06)',border:'1px solid rgba(239,68,68,.12)',color:'#EF4444',borderRadius:16,padding:'14px 0',fontSize:13,fontWeight:800,display:'flex',alignItems:'center',justifyContent:'center',gap:8,cursor:'pointer'}}><LogOut size={16} /> {t.out}</button>
      </div>
    </div>
  );
}
