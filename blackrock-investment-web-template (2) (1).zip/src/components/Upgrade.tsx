import { useStore } from '../store';
import { T, fmt, LVS } from '../utils';
import { Diamond, Rocket, Check, Send, Clipboard, Clock, Shield, Building2 } from 'lucide-react';

export function Upgrade() {
  const { user, lang, setSheet, toast2, updUser, closeSheet } = useStore();
  const t = T[lang];
  const ar = lang === 'ar';
  const SIGNAL_LINK = 'https://signal.me/#eu/8QzHlJCULtwT98_rnOOfdNxK5ndjabUYXgU8Zh8OsgPx3xc7m_hKhJUr0gUzR3cF';
  if (!user) return null;

  const copyCode = () => {
    navigator.clipboard.writeText(user.code).catch(() => {});
    toast2(ar ? 'تم نسخ كود الحساب' : 'Account code copied', 'success');
  };

  const openUpgradeRequest = (lv: typeof LVS[number]) => {
    const ref = `UP-${Date.now().toString().slice(-6)}`;
    setSheet(
      <div style={{display:'flex',flexDirection:'column',gap:12}}>
        <div style={{textAlign:'center'}}>
          <div className="bg-gold" style={{width:62,height:62,borderRadius:18,display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 12px',boxShadow:'0 0 24px rgba(212,175,55,.25)'}}>
            <Diamond size={30} color="#020509" />
          </div>
          <p style={{color:'#fff',fontSize:19,fontWeight:900,marginBottom:4}}>{ar ? 'طلب ترقية الحساب' : 'Account Upgrade Request'}</p>
          <p style={{color:'#D4AF37',fontSize:15,fontWeight:900}}>{lv.n} • {fmt(lv.p)} د.ج</p>
        </div>

        <div style={{background:'rgba(34,197,94,.06)',border:'1px solid rgba(34,197,94,.18)',borderRadius:14,padding:14,display:'flex',gap:10,alignItems:'flex-start'}}>
          <Shield size={18} color="#22C55E" style={{flexShrink:0,marginTop:2}} />
          <div>
            <p style={{color:'#22C55E',fontSize:14,fontWeight:900,marginBottom:4}}>{ar ? 'الدفع خارج التطبيق عبر CCP' : 'External CCP payment'}</p>
            <p style={{color:'rgba(255,255,255,.48)',fontSize:12,lineHeight:1.8,fontWeight:650}}>
              {ar ? 'لا يوجد دفع داخل التطبيق. تواصل مع وكلاء الشركة عبر Signal، ادفع لهم عبر CCP، ثم تتم ترقية حسابك حسب المستوى المطلوب.' : 'No in-app payment. Contact company agents through Signal, pay by CCP, then your account is upgraded to the requested level.'}
            </p>
          </div>
        </div>

        <div className="bg-card" style={{border:'1px solid rgba(212,175,55,.12)',borderRadius:14,padding:14}}>
          {[
            [ar?'المستوى':'Level', lv.n],
            [ar?'المبلغ المطلوب':'Required amount', fmt(lv.p)+' د.ج'],
            [ar?'كود حسابك':'Your account code', user.code],
            [ar?'رقم الطلب':'Request ID', ref],
            [ar?'طريقة الدفع':'Payment method', 'CCP / بريد الجزائر'],
          ].map((r,i)=>(
            <div key={i} style={{display:'flex',justifyContent:'space-between',alignItems:'center',gap:10,padding:'8px 0',borderBottom:i<4?'1px solid rgba(255,255,255,.04)':'none'}}>
              <span style={{color:'rgba(255,255,255,.4)',fontSize:12,fontWeight:750}}>{r[0]}</span>
              <span style={{color:'#fff',fontSize:12,fontWeight:900,textAlign:'left',direction:i===2||i===3?'ltr':undefined}}>{r[1]}</span>
            </div>
          ))}
        </div>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
          <button onClick={copyCode} style={{background:'rgba(255,255,255,.05)',border:'1px solid rgba(255,255,255,.08)',borderRadius:12,padding:'12px 0',color:'#fff',fontSize:13,fontWeight:900,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:6,fontFamily:'Tajawal,sans-serif'}}>
            <Clipboard size={15}/> {ar?'نسخ الكود':'Copy code'}
          </button>
          <button onClick={()=>{
            const req = {id:Date.now(),levelId:lv.id,levelName:lv.n,amount:lv.p,date:new Date().toISOString(),status:'pending' as const,ref};
            const notif = {id:Date.now()+1,title:ar?'💎 طلب ترقية جديد':'💎 New upgrade request',desc:`${lv.n} • ${fmt(lv.p)} د.ج • ${ref}`,t:new Date().toLocaleTimeString(),r:false};
            updUser({upgradeRequests:[...(user.upgradeRequests||[]),req],notifs:[...(user.notifs||[]),notif],activityLog:[...(user.activityLog||[]).slice(-30),new Date().toLocaleString()+` - upgrade request ${lv.n} ${ref}`]});
            closeSheet();
            toast2(ar?'تم حفظ طلب الترقية. تواصل مع الطاقم لإتمام الدفع.':'Upgrade request saved. Contact support to complete payment.','success');
          }} className="bg-gold" style={{border:'none',borderRadius:12,padding:'12px 0',color:'#020509',fontSize:13,fontWeight:900,cursor:'pointer',fontFamily:'Tajawal,sans-serif'}}>
            {ar?'حفظ الطلب':'Save request'}
          </button>
        </div>

        <div style={{display:'flex',flexDirection:'column',gap:8}}>
          {[
            {ic:Send,n:'Signal',v:ar?'رابط الوكلاء للشحن أو الاستثمار':'Agents link for deposit or investment',bg:'rgba(59,130,246,.09)',fn:()=>window.open(SIGNAL_LINK,'_blank')},
          ].map((ch,i)=>(
            <button key={i} onClick={ch.fn} style={{width:'100%',background:ch.bg,border:'1px solid rgba(59,130,246,.18)',borderRadius:14,padding:11,display:'flex',alignItems:'center',gap:10,cursor:'pointer',textAlign:ar?'right':'left'}}>
              <div style={{width:38,height:38,background:'rgba(255,255,255,.04)',borderRadius:11,display:'flex',alignItems:'center',justifyContent:'center',color:'rgba(255,255,255,.5)',flexShrink:0}}><ch.ic size={17}/></div>
              <div style={{minWidth:0}}><p style={{color:'#fff',fontWeight:900,fontSize:13}}>{ch.n}</p><p style={{color:'rgba(255,255,255,.32)',fontSize:11,direction:'ltr'}}>{ch.v}</p></div>
            </button>
          ))}
          <div style={{background:'rgba(0,0,0,.18)',border:'1px solid rgba(255,255,255,.06)',borderRadius:12,padding:10,color:'rgba(255,255,255,.55)',fontSize:10,wordBreak:'break-all',direction:'ltr',textAlign:'left'}}>{SIGNAL_LINK}</div>
        </div>

        <div style={{background:'rgba(255,255,255,.025)',border:'1px solid rgba(255,255,255,.05)',borderRadius:14,padding:12}}>
          <p style={{color:'rgba(255,255,255,.36)',fontSize:11,lineHeight:1.9,fontWeight:650}}>
            {ar ? 'مهم: بعد الدفع عبر CCP أرسل وصل الدفع، كود حسابك، ورقم الطلب عبر Signal. الترقية تتم يدوياً بعد التأكد من الدفع.' : 'Important: After CCP payment send receipt, account code, and request ID via Signal. Upgrade is applied manually after verification.'}
          </p>
        </div>
      </div>,
      ar?'💎 طلب ترقية':'💎 Upgrade Request'
    );
  };

  const openHistory = () => setSheet(
    <div style={{display:'flex',flexDirection:'column',gap:9}}>
      {(user.upgradeRequests||[]).length===0 ? <p style={{color:'rgba(255,255,255,.38)',textAlign:'center',fontSize:13,padding:'20px 0'}}>{ar?'لا توجد طلبات ترقية بعد':'No upgrade requests yet'}</p> :
        (user.upgradeRequests||[]).slice().reverse().map(req=>(
          <div key={req.id} className="bg-card" style={{border:'1px solid rgba(212,175,55,.1)',borderRadius:14,padding:13}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:7}}><span style={{color:'#fff',fontWeight:900,fontSize:13}}>{req.levelName}</span><span style={{color:req.status==='pending'?'#F59E0B':req.status==='approved'?'#22C55E':'#EF4444',fontSize:11,fontWeight:900}}>{req.status==='pending'?(ar?'قيد الدفع':'Pending'):req.status==='approved'?(ar?'مقبول':'Approved'):(ar?'مرفوض':'Rejected')}</span></div>
            <div style={{display:'flex',justifyContent:'space-between',color:'rgba(255,255,255,.35)',fontSize:11}}><span>{fmt(req.amount)} د.ج</span><span>{req.ref}</span></div>
          </div>
        ))}
    </div>, ar?'طلبات الترقية':'Upgrade Requests'
  );

  const activateTrial = () => { useStore.getState().updUser({level:'trial'}); toast2(ar?'✓ تم تفعيل التجربة المجانية':'✓ Free trial activated','success'); };

  const pending = (user.upgradeRequests||[]).filter(r=>r.status==='pending').length;

  return (
    <div className="an-enter" style={{paddingBottom:16}}>
      <div style={{position:'sticky',top:0,zIndex:40,background:'rgba(2,5,9,.97)',padding:'12px 16px',borderBottom:'1px solid rgba(212,175,55,.06)'}}>
        <div style={{display:'flex',alignItems:'center',gap:9}}>
          <div className="bg-gold" style={{width:34,height:34,borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',color:'#020509',flexShrink:0}}><Diamond size={18} /></div>
          <div><p style={{color:'#fff',fontWeight:900,fontSize:17}}>{t.plans}</p><p style={{color:'rgba(255,255,255,.3)',fontSize:10,fontWeight:800}}>{ar?'ترقية يدوية عبر طاقم الشركة':'Manual upgrade through company team'}</p></div>
        </div>
      </div>

      <div style={{padding:'12px 16px',display:'flex',flexDirection:'column',gap:11}}>
        <div className="bg-shim" style={{border:'1px solid rgba(212,175,55,.15)',borderRadius:18,padding:15}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',gap:10,marginBottom:10}}>
            <div><p style={{color:'rgba(255,255,255,.42)',fontSize:11,fontWeight:800}}>{ar?'نظام الترقية':'Upgrade System'}</p><p className="tg" style={{fontSize:18,fontWeight:900}}>{ar?'الدفع عبر CCP للطاقم':'CCP payment to team'}</p></div>
            <Building2 size={28} color="#D4AF37" />
          </div>
          <p style={{color:'rgba(255,255,255,.42)',fontSize:12,lineHeight:1.8,fontWeight:650}}>{ar?'اختر المستوى، تواصل مع الوكلاء عبر Signal، ادفع عبر CCP، ثم تتم ترقية حسابك بعد تأكيد الدفع. لا يتم خصم أي مبلغ من رصيد التطبيق.':'Choose a level, contact agents through Signal, pay by CCP, then your account is upgraded after payment verification. No in-app balance is deducted.'}</p>
        </div>

        {pending>0 && <button onClick={openHistory} style={{background:'rgba(245,158,11,.08)',border:'1px solid rgba(245,158,11,.18)',borderRadius:16,padding:13,display:'flex',alignItems:'center',justifyContent:'space-between',cursor:'pointer'}}><div style={{display:'flex',alignItems:'center',gap:8}}><Clock size={17} color="#F59E0B"/><span style={{color:'#fff',fontWeight:900,fontSize:13}}>{ar?'طلبات ترقية قيد المعالجة':'Pending upgrade requests'}</span></div><span style={{color:'#F59E0B',fontWeight:900}}>{pending}</span></button>}

        {LVS.map(lv => {
          const cur = user.level === lv.id;
          const trial = lv.id === 'trial';
          return (
            <div key={lv.id} className="bg-card" style={{border:cur?'1px solid rgba(34,197,94,.22)':'1px solid rgba(212,175,55,.1)',borderRadius:18,padding:15,opacity:cur?.85:1}}>
              <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:12}}>
                <div style={{display:'flex',alignItems:'center',gap:10}}><div className={cur?'':'bg-gold'} style={{width:44,height:44,borderRadius:12,display:'flex',alignItems:'center',justifyContent:'center',color:cur?'#22C55E':'#020509',background:cur?'rgba(34,197,94,.08)':undefined}}>{cur?<Check size={20}/>:<Rocket size={20}/>}</div><div><p style={{color:'#fff',fontWeight:900,fontSize:16}}>{lv.n}</p><p style={{color:trial?'#22C55E':'#D4AF37',fontSize:13,fontWeight:900}}>{trial?t.free:fmt(lv.p)+' د.ج'}</p></div></div>
                {cur && <span style={{background:'rgba(34,197,94,.1)',border:'1px solid rgba(34,197,94,.2)',borderRadius:99,padding:'3px 10px',color:'#22C55E',fontSize:10,fontWeight:900}}>✓ {t.active}</span>}
              </div>
              <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:5,marginBottom:12}}>{[{v:lv.dy+' د.ج',l:t.dy,c:'#22C55E'},{v:String(lv.d),l:t.days,c:'#D4AF37'},{v:String(lv.tot),l:t.tot,c:'#F97316'},{v:lv.mo?fmt(lv.mo):'—',l:t.mo,c:'#3B82F6'}].map((s,i)=><div key={i} style={{background:'rgba(255,255,255,.025)',border:'1px solid rgba(255,255,255,.035)',borderRadius:10,padding:'7px 2px',textAlign:'center'}}><p style={{color:s.c,fontWeight:900,fontSize:10}}>{s.v}</p><p style={{color:'rgba(255,255,255,.25)',fontSize:8,fontWeight:800,marginTop:1}}>{s.l}</p></div>)}</div>
              {!cur && trial && <button onClick={activateTrial} style={{width:'100%',background:'rgba(34,197,94,.08)',border:'1px solid rgba(34,197,94,.18)',color:'#22C55E',borderRadius:13,padding:'13px 0',fontSize:14,fontWeight:900,display:'flex',alignItems:'center',justifyContent:'center',gap:7,cursor:'pointer',fontFamily:'Tajawal,sans-serif'}}><Check size={17}/> {ar?'تفعيل التجربة المجانية':'Activate Free Trial'}</button>}
              {!cur && !trial && <button onClick={()=>openUpgradeRequest(lv)} className="bg-gold" style={{width:'100%',border:'none',color:'#020509',borderRadius:13,padding:'13px 0',fontSize:14,fontWeight:900,display:'flex',alignItems:'center',justifyContent:'center',gap:7,cursor:'pointer',fontFamily:'Tajawal,sans-serif'}}><Rocket size={17}/> {ar?'طلب ترقية عبر الشركة':'Request upgrade via company'}</button>}
            </div>
          );
        })}
      </div>
    </div>
  );
}