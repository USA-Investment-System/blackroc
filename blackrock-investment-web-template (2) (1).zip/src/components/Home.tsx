import { useStore } from '../store';
import { T, fmt, fDZD, lvN, lvD, MKT } from '../utils';
import { Shield, Bell, DownloadCloud, Upload, Diamond, Trophy, Gift, Share2, ChevronLeft, TrendingUp, Clock, CheckCircle, XCircle } from 'lucide-react';

export function Home() {
  const { user, lang, toggleLang, tasks, setTab, toast2, setSheet, closeSheet, setShowCompany, setShowInvest, updUser } = useStore();
  const t = T[lang];
  if (!user) return null;
  const MIN_WITHDRAW = 10000;
  const SIGNAL_LINK = 'https://signal.me/#eu/8QzHlJCULtwT98_rnOOfdNxK5ndjabUYXgU8Zh8OsgPx3xc7m_hKhJUr0gUzR3cF';
  const lv = lvD(user.level);
  const done = tasks?.filter(x => x.status === 'done').length || 0;
  const totalTasks = tasks?.length || 5;
  const unread = user.notifs?.filter(n => !n.r).length || 0;
  const prog = (user.m1Refs || 0) % 10;
  const perTask = Math.max(43, Math.round(lv.dy / 5));

  // ===== DEPOSIT (شحن) =====
  const openDeposit = () => {
    const ar = lang === 'ar';
    setSheet(
      <div style={{display:'flex',flexDirection:'column',gap:12}}>
        <div style={{textAlign:'center',marginBottom:4}}>
          <div style={{width:56,height:56,background:'linear-gradient(135deg,#D4AF37,#C9992C)',borderRadius:16,display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 10px'}}><Upload size={26} color="#020509" /></div>
          <p style={{color:'#fff',fontWeight:900,fontSize:18,marginBottom:4}}>{ar?'شحن الرصيد':'Deposit Funds'}</p>
          <p style={{color:'rgba(255,255,255,.4)',fontSize:13,fontWeight:700}}>{ar?'تواصل معنا عبر Signal للشحن':'Contact us on Signal to deposit'}</p>
        </div>

        <div style={{background:'rgba(212,175,55,.06)',border:'1px solid rgba(212,175,55,.15)',borderRadius:14,padding:14}}>
          <p style={{color:'#D4AF37',fontWeight:900,fontSize:15,marginBottom:8,textAlign:'center'}}>🔐 Signal</p>
          <p style={{color:'#fff',fontWeight:800,fontSize:13,lineHeight:1.8,textAlign:'center'}}>{ar?'هذا رابطنا، تجدون فيه الوكلاء للشحن أو الاستثمار:':'This is our link, you will find our agents for deposit or investment:'}</p>
          <div style={{background:'rgba(0,0,0,.18)',border:'1px solid rgba(255,255,255,.06)',borderRadius:12,padding:10,marginTop:10,color:'rgba(255,255,255,.55)',fontSize:11,wordBreak:'break-all',direction:'ltr',textAlign:'left'}}>{SIGNAL_LINK}</div>
        </div>

        <div style={{background:'rgba(255,255,255,.02)',border:'1px solid rgba(255,255,255,.05)',borderRadius:14,padding:14}}>
          <p style={{color:'rgba(255,255,255,.5)',fontSize:13,fontWeight:700,marginBottom:6}}>{ar?'⚠️ تعليمات مهمة:':'⚠️ Important Instructions:'}</p>
          <div style={{color:'rgba(255,255,255,.35)',fontSize:12,lineHeight:2,fontWeight:600}}>
            {ar ? <>
              • تواصل مع الوكلاء عبر Signal فقط<br/>
              • أرسل المبلغ المطلوب مع كود حسابك: <span style={{color:'#D4AF37',fontWeight:800}}>{user.code}</span><br/>
              • سيتم تفعيل الرصيد خلال 15 دقيقة<br/>
              • الشحن بدون حد أدنى أو حد أقصى<br/>
              • لا يوجد شحن عبر Baridimob أو CCP مباشرة
            </> : <>
              • Contact agents through Signal only<br/>
              • Send amount with your code: <span style={{color:'#D4AF37',fontWeight:800}}>{user.code}</span><br/>
              • Balance activated within 15 minutes<br/>
              • Deposit has no minimum or maximum limit<br/>
              • No direct Baridimob or CCP deposits
            </>}
          </div>
        </div>

        <button onClick={()=>{
          window.open(SIGNAL_LINK,'_blank');
        }} style={{width:'100%',background:'linear-gradient(135deg,#3A76F0,#2546D8)',border:'none',borderRadius:14,color:'#fff',padding:'14px 0',fontSize:16,fontWeight:900,cursor:'pointer',fontFamily:'Tajawal,sans-serif',display:'flex',alignItems:'center',justifyContent:'center',gap:8}}>
          🔐 {ar?'فتح Signal والتواصل مع الوكلاء':'Open Signal and contact agents'}
        </button>
      </div>,
      ar?'💰 شحن الرصيد':'💰 Deposit Funds'
    );
  };

  // ===== WITHDRAW (سحب CCP) =====
  const openWithdraw = () => {
    const ar = lang === 'ar';
    if (!user.level || user.level === 'trial') { toast2(ar?'⚠️ يتطلب مستوى M1 على الأقل':'⚠️ Requires M1 level','warning'); setTab('up'); return; }
    if ((user.balance || 0) < MIN_WITHDRAW) { toast2(ar?`⚠️ الحد الأدنى للسحب ${fmt(MIN_WITHDRAW)} د.ج`:`⚠️ Minimum withdrawal ${fmt(MIN_WITHDRAW)} د.ج`,'warning'); return; }

    let ccpVal = '';
    let nameVal = '';
    let amtVal = '';

    const renderForm = () => {
      setSheet(
        <div style={{display:'flex',flexDirection:'column',gap:12}}>
          <div style={{textAlign:'center',marginBottom:4}}>
            <div style={{width:56,height:56,background:'rgba(34,197,94,.1)',borderRadius:16,display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 10px',color:'#22C55E'}}><DownloadCloud size={26} /></div>
            <p style={{color:'#fff',fontWeight:900,fontSize:18,marginBottom:4}}>{ar?'سحب الأموال':'Withdraw Funds'}</p>
            <p style={{color:'rgba(255,255,255,.4)',fontSize:13,fontWeight:700}}>{ar?'السحب عبر CCP بريد الجزائر فقط':'Withdrawal via CCP Algeria Post only'}</p>
          </div>

          {/* Available Balance */}
          <div style={{background:'rgba(34,197,94,.06)',border:'1px solid rgba(34,197,94,.15)',borderRadius:14,padding:14,textAlign:'center'}}>
            <p style={{color:'rgba(255,255,255,.4)',fontSize:12,fontWeight:700,marginBottom:4}}>{ar?'الرصيد المتاح للسحب':'Available for Withdrawal'}</p>
            <p style={{fontFamily:'Montserrat,sans-serif',fontSize:24,fontWeight:900,color:'#22C55E'}}>{fmt(user.balance||0)} <span style={{fontSize:12,color:'rgba(255,255,255,.3)'}}>د.ج</span></p>
          </div>

          {/* CCP Number */}
          <div>
            <label style={{display:'block',color:'rgba(255,255,255,.5)',fontSize:12,fontWeight:800,marginBottom:6}}>{ar?'رقم حساب CCP':'CCP Account Number'} *</label>
            <input
              defaultValue={ccpVal}
              onChange={e => ccpVal = e.target.value}
              placeholder={ar?'مثال: 1234567890 CLE 42':'Example: 1234567890 CLE 42'}
              style={{width:'100%',background:'rgba(255,255,255,.04)',border:'1px solid rgba(255,255,255,.1)',borderRadius:12,color:'#fff',padding:'13px 14px',fontSize:15,fontWeight:700,outline:'none',fontFamily:'Montserrat,sans-serif',direction:'ltr',textAlign:'left'}}
            />
          </div>

          {/* Full Name */}
          <div>
            <label style={{display:'block',color:'rgba(255,255,255,.5)',fontSize:12,fontWeight:800,marginBottom:6}}>{ar?'الاسم الكامل (كما في CCP)':'Full Name (as on CCP)'} *</label>
            <input
              defaultValue={nameVal}
              onChange={e => nameVal = e.target.value}
              placeholder={ar?'الاسم واللقب':'First and Last Name'}
              style={{width:'100%',background:'rgba(255,255,255,.04)',border:'1px solid rgba(255,255,255,.1)',borderRadius:12,color:'#fff',padding:'13px 14px',fontSize:15,fontWeight:700,outline:'none',fontFamily:'Tajawal,sans-serif'}}
            />
          </div>

          {/* Amount */}
          <div>
            <label style={{display:'block',color:'rgba(255,255,255,.5)',fontSize:12,fontWeight:800,marginBottom:6}}>{ar?'المبلغ المراد سحبه (د.ج)':'Amount to Withdraw (د.ج)'} *</label>
            <input
              type="number"
              defaultValue={amtVal}
              onChange={e => amtVal = e.target.value}
              placeholder={String(MIN_WITHDRAW)}
              style={{width:'100%',background:'rgba(255,255,255,.04)',border:'1px solid rgba(255,255,255,.1)',borderRadius:12,color:'#fff',padding:'13px 14px',fontSize:16,fontWeight:700,outline:'none',fontFamily:'Montserrat,sans-serif'}}
            />
            {/* Quick amounts */}
            <div style={{display:'flex',gap:6,marginTop:8,flexWrap:'wrap'}}>
              {[MIN_WITHDRAW, 20000, 50000, 100000, user.balance||0].filter((v,i,a) => v >= MIN_WITHDRAW && v <= (user.balance||0) && a.indexOf(v)===i).map(v => (
                <button key={v} onClick={() => { amtVal = String(v); renderForm(); }} style={{padding:'5px 12px',background:'rgba(255,255,255,.04)',border:'1px solid rgba(255,255,255,.08)',borderRadius:8,color:'rgba(255,255,255,.5)',fontSize:12,fontWeight:700,cursor:'pointer',fontFamily:'Montserrat,sans-serif'}}>{fmt(v)}</button>
              ))}
            </div>
          </div>

          {/* Processing time */}
          <div style={{display:'flex',alignItems:'center',gap:8,padding:'10px 14px',background:'rgba(245,158,11,.06)',border:'1px solid rgba(245,158,11,.15)',borderRadius:12}}>
            <Clock size={16} color="#F59E0B" style={{flexShrink:0}} />
            <p style={{color:'#F59E0B',fontSize:13,fontWeight:800}}>{ar?'مدة المعالجة: 48 إلى 72 ساعة':'Processing time: 48 to 72 hours'}</p>
          </div>

          {/* Rules */}
          <div style={{background:'rgba(255,255,255,.02)',border:'1px solid rgba(255,255,255,.04)',borderRadius:12,padding:12}}>
            <p style={{color:'rgba(255,255,255,.3)',fontSize:11,lineHeight:1.9,fontWeight:600}}>
              {ar ? <>
                • السحب عبر CCP بريد الجزائر فقط<br/>
                • الحد الأدنى: {fmt(MIN_WITHDRAW)} د.ج<br/>
                • يجب أن يكون الاسم مطابقاً لحساب CCP<br/>
                • مدة المعالجة: 48-72 ساعة عمل<br/>
                • يتطلب مستوى M1 على الأقل
              </> : <>
                • CCP Algeria Post only<br/>
                • Minimum: {fmt(MIN_WITHDRAW)} د.ج<br/>
                • Name must match CCP account<br/>
                • Processing: 48-72 business hours<br/>
                • Requires M1 level minimum
              </>}
            </p>
          </div>

          {/* Submit */}
          <button onClick={() => {
            const amt = parseFloat(amtVal);
            if (!ccpVal.trim()) { toast2(ar?'أدخل رقم CCP':'Enter CCP number','error'); return; }
            if (!nameVal.trim()) { toast2(ar?'أدخل الاسم الكامل':'Enter full name','error'); return; }
            if (!amt || amt < MIN_WITHDRAW) { toast2(ar?`الحد الأدنى ${fmt(MIN_WITHDRAW)} د.ج`:`Minimum ${fmt(MIN_WITHDRAW)} د.ج`,'error'); return; }
            if (amt > (user.balance||0)) { toast2(ar?'رصيد غير كافي':'Insufficient balance','error'); return; }

            const newW = { id: Date.now(), amount: amt, ccp: ccpVal.trim(), name: nameVal.trim(), date: new Date().toISOString(), status: 'pending' as const };
            const newNotif = { id: Date.now(), title: ar?'💳 طلب سحب جديد':'💳 New Withdrawal', desc: `${fmt(amt)} د.ج → CCP: ${ccpVal.trim()}`, t: new Date().toLocaleTimeString(), r: false };
            updUser({
              balance: (user.balance||0) - amt,
              withdrawals: [...(user.withdrawals||[]), newW],
              notifs: [...(user.notifs||[]), newNotif],
            });
            closeSheet();
            toast2(ar?'✅ تم إرسال طلب السحب! سيتم المعالجة خلال 48-72 ساعة':'✅ Withdrawal submitted! Processing in 48-72 hours','success');
          }} style={{width:'100%',background:'linear-gradient(135deg,#22C55E,#16A34A)',border:'none',borderRadius:14,color:'#fff',padding:'15px 0',fontSize:16,fontWeight:900,cursor:'pointer',fontFamily:'Tajawal,sans-serif'}}>
            {ar?'تأكيد السحب ✅':'Confirm Withdrawal ✅'}
          </button>
        </div>,
        ar?'💳 سحب الأموال':'💳 Withdraw Funds'
      );
    };
    renderForm();
  };

  // ===== WITHDRAWAL HISTORY =====
  const openWithdrawHistory = () => {
    const ar = lang === 'ar';
    const wds = user.withdrawals || [];
    setSheet(
      <div style={{display:'flex',flexDirection:'column',gap:10}}>
        {wds.length === 0 ? (
          <div style={{textAlign:'center',padding:32}}>
            <p style={{fontSize:40,marginBottom:8}}>📭</p>
            <p style={{color:'rgba(255,255,255,.4)',fontSize:15,fontWeight:800}}>{ar?'لا توجد طلبات سحب':'No withdrawal requests'}</p>
          </div>
        ) : wds.slice().reverse().map(w => (
          <div key={w.id} style={{background:'linear-gradient(160deg,rgba(10,16,32,.98),rgba(7,12,24,.99))',border:`1px solid ${w.status==='approved'?'rgba(34,197,94,.15)':w.status==='rejected'?'rgba(239,68,68,.15)':'rgba(245,158,11,.15)'}`,borderRadius:14,padding:14}}>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:8}}>
              <div style={{display:'flex',alignItems:'center',gap:8}}>
                {w.status==='pending' && <Clock size={16} color="#F59E0B" />}
                {w.status==='approved' && <CheckCircle size={16} color="#22C55E" />}
                {w.status==='rejected' && <XCircle size={16} color="#EF4444" />}
                <p style={{color:'#fff',fontWeight:800,fontSize:14}}>{fmt(w.amount)} د.ج</p>
              </div>
              <span style={{
                padding:'3px 10px',borderRadius:8,fontSize:11,fontWeight:800,
                ...(w.status==='pending'?{background:'rgba(245,158,11,.1)',color:'#F59E0B'}:
                   w.status==='approved'?{background:'rgba(34,197,94,.1)',color:'#22C55E'}:
                   {background:'rgba(239,68,68,.1)',color:'#EF4444'})
              }}>
                {w.status==='pending'?(ar?'⏳ قيد المعالجة':'⏳ Pending'):
                 w.status==='approved'?(ar?'✅ تمت الموافقة':'✅ Approved'):
                 (ar?'❌ مرفوض':'❌ Rejected')}
              </span>
            </div>
            <div style={{display:'flex',justifyContent:'space-between',color:'rgba(255,255,255,.3)',fontSize:11,fontWeight:600}}>
              <span>CCP: {w.ccp}</span>
              <span>{new Date(w.date).toLocaleDateString()}</span>
            </div>
          </div>
        ))}
      </div>,
      ar?'📋 سجل السحوبات':'📋 Withdrawal History'
    );
  };
  const cpRef = () => { navigator.clipboard.writeText(user.ref).catch(() => {}); toast2(t.copied, 'success'); };
  const shareRef = () => {
    const msg = `🏦 BlackRock\n${user.ref}\n💰 ${lang === 'ar' ? 'اربح يومياً!' : 'Earn daily!'}`;
    if (navigator.share) navigator.share({ title: 'BlackRock', text: msg, url: user.ref }).catch(() => {});
    else { navigator.clipboard.writeText(msg).catch(() => {}); toast2(t.copied, 'success'); }
  };
  const openNotifs = () => {
    useStore.getState().updUser({ notifs: (user.notifs || []).map(n => ({ ...n, r: true })) });
    setSheet(
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {(user.notifs || []).length === 0
          ? <p style={{ textAlign: 'center', padding: 32, color: 'rgba(255,255,255,.3)', fontSize: 14 }}>{t.noNotifs}</p>
          : (user.notifs || []).map(n => (
            <div key={n.id} style={{
              background: 'linear-gradient(160deg, rgba(10,16,32,.98), rgba(7,12,24,.99))',
              border: '1px solid rgba(255,255,255,.05)', borderRadius: 14,
              padding: 12, display: 'flex', gap: 10, alignItems: 'flex-start',
            }}>
              <div style={{ width: 36, height: 36, background: 'rgba(255,255,255,.04)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, color: '#D4AF37' }}><Bell size={16} /></div>
              <div style={{ minWidth: 0 }}>
                <p style={{ color: '#fff', fontWeight: 800, fontSize: 13, marginBottom: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{n.title}</p>
                <p style={{ color: 'rgba(255,255,255,.45)', fontSize: 11, lineHeight: 1.5 }}>{n.desc}</p>
                <p style={{ color: 'rgba(255,255,255,.25)', fontSize: 10, marginTop: 4 }}>{n.t}</p>
              </div>
            </div>
          ))}
      </div>, t.notifs
    );
  };

  // Card style helper
  const card: React.CSSProperties = {
    background: 'linear-gradient(160deg, rgba(10,16,32,.98), rgba(7,12,24,.99))',
    border: '1px solid rgba(255,255,255,.06)',
    borderRadius: 16,
  };
  const cardGold: React.CSSProperties = { ...card, border: '1px solid rgba(212,175,55,.14)' };
  const shimCard: React.CSSProperties = {
    background: 'linear-gradient(160deg, rgba(12,18,36,.98), rgba(8,13,26,.99))',
    border: '1px solid rgba(212,175,55,.14)',
    borderRadius: 16,
  };

  return (
    <div className="an-enter" style={{ paddingBottom: 16 }}>
      {/* Header */}
      <div style={{
        position: 'sticky', top: 0, zIndex: 40,
        background: 'rgba(2,5,9,.97)',
        padding: '10px 16px 0',
        borderBottom: '1px solid rgba(212,175,55,.06)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
          {/* Logo */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{
              width: 28, height: 28, borderRadius: 8,
              background: 'linear-gradient(135deg, #D4AF37, #C9992C)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}>
              <Diamond size={14} color="#020509" strokeWidth={2.5} />
            </div>
            <div>
              <p style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 13, fontWeight: 900, letterSpacing: 2, color: '#D4AF37', lineHeight: 1 }}>BLACKROCK</p>
              <p style={{ fontSize: 8, color: 'rgba(255,255,255,.25)', letterSpacing: 1, fontWeight: 700 }}>{t.sub.toUpperCase()}</p>
            </div>
          </div>

          {/* Right actions */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <button onClick={toggleLang} style={{
              background: 'rgba(212,175,55,.06)', border: '1px solid rgba(212,175,55,.14)',
              borderRadius: 99, padding: '2px 8px', color: '#D4AF37', fontSize: 9, fontWeight: 800, cursor: 'pointer',
              fontFamily: 'Tajawal, sans-serif',
            }}>{t.lang}</button>
            <span style={{
              background: 'rgba(34,197,94,.07)', border: '1px solid rgba(34,197,94,.16)',
              borderRadius: 99, padding: '2px 7px', display: 'inline-flex', alignItems: 'center', gap: 3,
            }}>
              <Shield size={9} color="#22C55E" /><span style={{ color: '#22C55E', fontSize: 8, fontWeight: 800 }}>BLK</span>
            </span>
            <button onClick={openNotifs} style={{ position: 'relative', background: 'none', border: 'none', cursor: 'pointer', padding: 0 }}>
              <div style={{
                width: 32, height: 32,
                background: 'rgba(212,175,55,.06)', border: '1px solid rgba(212,175,55,.12)',
                borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#D4AF37',
              }}><Bell size={16} /></div>
              {unread > 0 && <span style={{
                position: 'absolute', top: -4, right: -4,
                minWidth: 14, height: 14, background: '#EF4444', borderRadius: 7,
                border: '1.5px solid #020509', fontSize: 7, fontWeight: 900, color: '#fff',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>{unread}</span>}
            </button>
          </div>
        </div>

        {/* Ticker */}
        <div style={{
          overflow: 'hidden',
          background: 'rgba(212,175,55,.03)',
          borderBottom: '1px solid rgba(212,175,55,.05)',
          margin: '0 -16px',
        }}>
          <div className="an-ticker" style={{ display: 'flex', whiteSpace: 'nowrap', padding: '5px 0' }}>
            {[...MKT, ...MKT, ...MKT].map((m, i) => (
              <span key={i} style={{ display: 'inline-flex', alignItems: 'center', gap: 4, padding: '0 12px', flexShrink: 0, fontSize: 9 }}>
                <span style={{ color: 'rgba(255,255,255,.4)', fontWeight: 700 }}>{m.s}</span>
                <span style={{ fontFamily: 'Montserrat, sans-serif', color: '#D4AF37', fontWeight: 800 }}>{m.v}</span>
                <span style={{ color: m.up ? '#22C55E' : '#EF4444', fontWeight: 700 }}>{m.up ? '▲' : '▼'}{m.p}%</span>
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <div style={{ padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: 12 }}>

        {/* Balance Card */}
        <div style={{ ...shimCard, padding: 16 }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 14 }}>
            <div>
              <p style={{ color: 'rgba(255,255,255,.4)', fontSize: 10, fontWeight: 700, letterSpacing: 0.5, marginBottom: 4 }}>{t.bal.toUpperCase()}</p>
              <p style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 30, fontWeight: 900, lineHeight: 1 }} className="tg">{fmt(user.balance || 0)}</p>
              <p style={{ color: 'rgba(255,255,255,.3)', fontSize: 10, fontWeight: 700, marginTop: 2 }}>د.ج</p>
            </div>
            <div style={{ textAlign: 'center' }}>
              {user.avatar ? <img src={user.avatar} alt="avatar" style={{width:48,height:48,borderRadius:24,objectFit:'cover',border:'2px solid rgba(212,175,55,.8)'}}/> : <div style={{
                width: 48, height: 48, borderRadius: 24,
                background: 'linear-gradient(135deg, #D4AF37, #C9992C)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 18, fontWeight: 900, color: '#020509',
              }}>{(user.un || '?')[0].toUpperCase()}</div>}
              <span style={{
                display: 'inline-block', marginTop: 4,
                background: 'rgba(212,175,55,.1)', border: '1px solid rgba(212,175,55,.2)',
                borderRadius: 99, padding: '1px 8px', color: '#D4AF37', fontSize: 9, fontWeight: 800,
              }}>{lvN(user.level)}</span>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 6 }}>
            {[
              { v: String(user.teamCount || 0), l: t.team, c: '#D4AF37' },
              { v: `${done}/${totalTasks}`, l: t.done, c: '#22C55E' },
              { v: `+${lv.dy}`, l: t.daily, c: '#3B82F6' },
            ].map((s, i) => (
              <div key={i} style={{ background: 'rgba(255,255,255,.03)', borderRadius: 10, padding: '8px 4px', textAlign: 'center' }}>
                <p style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 13, fontWeight: 900, color: s.c }}>{s.v}</p>
                <p style={{ color: 'rgba(255,255,255,.3)', fontSize: 9, fontWeight: 700, marginTop: 2 }}>{s.l}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          {[
            { fn: openDeposit, ic: Upload, l: lang === 'ar' ? 'شحن' : 'Deposit', d: lang === 'ar' ? 'شحن الرصيد' : 'Add Funds', c: '#D4AF37', bg: 'rgba(212,175,55,.07)' },
            { fn: openWithdraw, ic: DownloadCloud, l: t.wd, d: 'CCP فقط', c: '#22C55E', bg: 'rgba(34,197,94,.07)' },
          ].map((a, i) => (
            <button key={i} onClick={a.fn} style={{
              ...card, padding: 12, display: 'flex', alignItems: 'center', gap: 10,
              cursor: 'pointer', textAlign: lang === 'ar' ? 'right' : 'left',
            }}>
              <div style={{ width: 40, height: 40, background: a.bg, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', color: a.c, flexShrink: 0 }}>
                <a.ic size={20} />
              </div>
              <div style={{ minWidth: 0 }}>
                <p style={{ color: '#fff', fontWeight: 800, fontSize: 13, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.l}</p>
                <p style={{ color: 'rgba(255,255,255,.3)', fontSize: 10, fontWeight: 700 }}>{a.d}</p>
              </div>
            </button>
          ))}
        </div>

        {/* Withdrawal History (if any) */}
        {(user.withdrawals||[]).length > 0 && (
          <button onClick={openWithdrawHistory} style={{
            width: '100%',
            background: 'linear-gradient(160deg, rgba(10,16,32,.98), rgba(7,12,24,.99))',
            border: '1px solid rgba(245,158,11,.15)',
            borderRadius: 16, padding: 14,
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            cursor: 'pointer',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <Clock size={18} color="#F59E0B" />
              <div>
                <p style={{ color: '#fff', fontWeight: 800, fontSize: 13 }}>{lang === 'ar' ? '📋 سجل السحوبات' : '📋 Withdrawal History'}</p>
                <p style={{ color: 'rgba(255,255,255,.35)', fontSize: 11, fontWeight: 700 }}>
                  {(user.withdrawals||[]).filter(w=>w.status==='pending').length > 0
                    ? (lang === 'ar' ? `${(user.withdrawals||[]).filter(w=>w.status==='pending').length} طلب قيد المعالجة` : `${(user.withdrawals||[]).filter(w=>w.status==='pending').length} pending`)
                    : (lang === 'ar' ? 'عرض جميع الطلبات' : 'View all requests')}
                </p>
              </div>
            </div>
            <ChevronLeft size={16} color="rgba(255,255,255,.2)" style={{ transform: lang === 'ar' ? 'none' : 'rotate(180deg)' }} />
          </button>
        )}

        {/* Investment Banner */}
        <button onClick={() => setShowInvest(true)} style={{
          width: '100%',
          background: 'linear-gradient(135deg, rgba(212,175,55,.1), rgba(184,134,11,.06))',
          border: '1px solid rgba(212,175,55,.2)',
          borderRadius: 16, padding: 16,
          display: 'flex', alignItems: 'center', gap: 12,
          cursor: 'pointer',
          textAlign: lang === 'ar' ? 'right' : 'left',
        }}>
          <div style={{
            width: 48, height: 48, borderRadius: 14,
            background: 'linear-gradient(135deg, #D4AF37, #B8860B)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0, boxShadow: '0 4px 12px rgba(212,175,55,.3)',
          }}><TrendingUp size={24} color="#020509" /></div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <p style={{ color: '#D4AF37', fontWeight: 900, fontSize: 15, marginBottom: 2 }}>
              {lang === 'ar' ? '📈 استثمار BlackRock' : '📈 BlackRock Invest'}
            </p>
            <p style={{ color: 'rgba(255,255,255,.4)', fontSize: 12, fontWeight: 700 }}>
              {lang === 'ar' ? 'صناديق استثمارية بعوائد يومية مضمونة' : 'Investment funds with guaranteed daily returns'}
            </p>
          </div>
          <ChevronLeft size={18} color="rgba(212,175,55,.5)" style={{ flexShrink: 0, transform: lang === 'ar' ? 'none' : 'rotate(180deg)' }} />
        </button>

        {/* Competition */}
        <div style={{
          background: 'linear-gradient(135deg, rgba(168,85,247,.07), rgba(139,92,246,.03))',
          border: '1px solid rgba(168,85,247,.18)', borderRadius: 16, padding: 14,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
              <Trophy size={18} color="#A855F7" style={{ flexShrink: 0 }} />
              <div style={{ minWidth: 0 }}>
                <p style={{ color: '#fff', fontWeight: 800, fontSize: 13, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.compT}</p>
                <p style={{ color: 'rgba(255,255,255,.3)', fontSize: 10, fontWeight: 700 }}>{t.compS}</p>
              </div>
            </div>
            <span style={{
              background: 'rgba(168,85,247,.1)', border: '1px solid rgba(168,85,247,.2)',
              borderRadius: 99, padding: '2px 10px', color: '#A855F7', fontSize: 10, fontWeight: 800, flexShrink: 0,
            }}>{prog}/10</span>
          </div>
          <div style={{ background: 'rgba(255,255,255,.07)', borderRadius: 4, height: 5, overflow: 'hidden' }}>
            <div style={{ height: '100%', background: 'linear-gradient(90deg, #A855F7, #8B5CF6)', borderRadius: 4, width: `${prog * 10}%` }} />
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', color: 'rgba(255,255,255,.3)', fontSize: 9, fontWeight: 700, marginTop: 4 }}>
            <span>{t.prog}: {prog}/10</span><span>{t.goal}</span>
          </div>
        </div>

        {/* Referral */}
        <div style={{ ...cardGold, padding: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
            <div style={{
              width: 40, height: 40, borderRadius: 10,
              background: 'linear-gradient(135deg, #D4AF37, #C9992C)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
            }}><Gift size={20} color="#020509" /></div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ color: '#fff', fontWeight: 800, fontSize: 14 }}>🎯 {lang==='ar'?'رابط الدعوة الوحيد':'Single referral link'}</p>
              <p style={{ color: 'rgba(255,255,255,.3)', fontSize: 10, fontWeight: 700 }}>{t.ref2}</p>
            </div>
            <span style={{
              background: 'rgba(212,175,55,.1)', border: '1px solid rgba(212,175,55,.2)',
              borderRadius: 99, padding: '2px 10px', color: '#D4AF37', fontSize: 11, fontWeight: 800, flexShrink: 0,
            }}>5%</span>
          </div>
          <div style={{
            background: 'rgba(212,175,55,.03)', border: '1px solid rgba(212,175,55,.08)',
            borderRadius: 10, padding: '7px 10px', display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10,
          }}>
            <span style={{ flex: 1, color: 'rgba(255,255,255,.35)', fontSize: 10, fontWeight: 700, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', textAlign: 'center', direction: 'ltr' }}>{user.ref}</span>
            <button onClick={cpRef} style={{
              background: 'linear-gradient(135deg, #D4AF37, #C9992C)',
              border: 'none', borderRadius: 8, color: '#020509',
              fontSize: 10, fontWeight: 800, padding: '4px 10px', cursor: 'pointer', flexShrink: 0,
            }}>{t.copy}</button>
          </div>
          <button onClick={shareRef} style={{
            width: '100%', background: 'linear-gradient(135deg, #D4AF37, #C9992C, #B8860B)',
            border: 'none', borderRadius: 12, color: '#020509',
            padding: '12px 0', fontSize: 14, fontWeight: 800,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, cursor: 'pointer',
            fontFamily: 'Tajawal, sans-serif',
          }}><Share2 size={16} /> {t.share}</button>
          <p style={{ textAlign: 'center', marginTop: 6, color: 'rgba(255,255,255,.25)', fontSize: 9, fontWeight: 700 }}>{t.ef}</p>
        </div>

        {/* Portfolio */}
        <div>
          <p style={{ color: '#fff', fontWeight: 800, fontSize: 14, marginBottom: 8 }}>📊 {t.pf}</p>
          <div style={{ ...card, padding: 12 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
              {[
                { v: fDZD(user.totalEarned || 0), l: t.earned, c: '#22C55E' },
                { v: fDZD(user.refEarn || 0), l: t.refE, c: '#D4AF37' },
                { v: `+${done * perTask} د.ج`, l: t.tod, c: '#3B82F6' },
                { v: lv.mo ? fDZD(lv.mo) : '—', l: t.mon, c: '#D4AF37' },
              ].map((s, i) => (
                <div key={i} style={{ background: 'rgba(255,255,255,.02)', border: '1px solid rgba(255,255,255,.04)', borderRadius: 10, padding: 10 }}>
                  <p style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 12, fontWeight: 800, color: s.c, marginBottom: 2 }}>{s.v}</p>
                  <p style={{ color: 'rgba(255,255,255,.3)', fontSize: 9, fontWeight: 700 }}>{s.l}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Company */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <p style={{ color: '#fff', fontWeight: 800, fontSize: 14 }}>🏢 {t.co}</p>
            <button onClick={() => setShowCompany(true)} style={{
              color: '#D4AF37', fontSize: 12, fontWeight: 800,
              background: 'none', border: 'none', cursor: 'pointer',
              display: 'flex', alignItems: 'center', gap: 2,
              fontFamily: 'Tajawal, sans-serif',
            }}>{t.det} <ChevronLeft size={14} style={{ transform: lang === 'ar' ? 'none' : 'rotate(180deg)' }} /></button>
          </div>
          <div style={{ ...cardGold, padding: 12 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
              {[
                { v: 'NYSE: BLK', l: lang === 'ar' ? 'رمز التداول' : 'Stock', c: '#D4AF37' },
                { v: 'Jan 2025', l: lang === 'ar' ? 'بدء العقد' : 'Contract Start', c: '#22C55E' },
                { v: 'Dec 2027', l: lang === 'ar' ? 'انتهاء العقد' : 'Contract End', c: '#D4AF37' },
                { v: 'AES-256', l: lang === 'ar' ? 'التشفير' : 'Encryption', c: '#3B82F6' },
              ].map((s, i) => (
                <div key={i} style={{ background: 'rgba(255,255,255,.02)', border: '1px solid rgba(255,255,255,.04)', borderRadius: 10, padding: '8px 4px', textAlign: 'center' }}>
                  <p style={{ fontFamily: 'Montserrat, sans-serif', fontSize: 11, fontWeight: 800, color: s.c }}>{s.v}</p>
                  <p style={{ color: 'rgba(255,255,255,.25)', fontSize: 9, fontWeight: 700, marginTop: 2 }}>{s.l}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
