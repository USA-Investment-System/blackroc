// Supabase Client - Real Backend Database
const ENV = (import.meta as any).env || {};
const SUPABASE_URL = ENV.VITE_SUPABASE_URL || '';
const SUPABASE_KEY = ENV.VITE_SUPABASE_ANON_KEY || '';

export const SUPABASE_ENABLED = Boolean(SUPABASE_URL && SUPABASE_KEY);

// Initialize Supabase client (lightweight fetch-based)
async function supabaseFetch(endpoint: string, options: RequestInit = {}) {
  if (!SUPABASE_ENABLED) {
    throw new Error('Supabase not configured');
  }
  
  const response = await fetch(`${SUPABASE_URL}/rest/v1/${endpoint}`, {
    ...options,
    headers: {
      'apikey': SUPABASE_KEY,
      'Authorization': `Bearer ${SUPABASE_KEY}`,
      'Content-Type': 'application/json',
      'Prefer': 'return=representation',
      ...options.headers,
    },
  });
  
  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Supabase error: ${error}`);
  }
  
  if (response.status === 204) return null;
  return response.json();
}

// Database operations
export const db = {
  // Get user by code
  getUserByCode: async (code: string) => {
    try {
      const users = await supabaseFetch(`br_users?code=eq.${code}&limit=1`);
      return users?.[0]?.payload || null;
    } catch {
      return null;
    }
  },
  
  // Get user by username
  getUserByUsername: async (username: string) => {
    try {
      const users = await supabaseFetch(`br_users?username=eq.${username}&limit=1`);
      return users?.[0]?.payload || null;
    } catch {
      return null;
    }
  },
  
  // Create new user
  createUser: async (user: any) => {
    try {
      await supabaseFetch('br_users', {
        method: 'POST',
        body: JSON.stringify({
          id: String(user.id),
          username: user.un,
          code: user.code,
          payload: user,
        }),
        headers: { 'Prefer': 'resolution=merge-duplicates' },
      });
      return user;
    } catch (e) {
      console.error('Create user error:', e);
      return null;
    }
  },
  
  // Update user
  updateUser: async (user: any) => {
    try {
      await supabaseFetch(`br_users?id=eq.${user.id}`, {
        method: 'PATCH',
        body: JSON.stringify({
          payload: user,
          updated_at: new Date().toISOString(),
        }),
      });
      return user;
    } catch (e) {
      console.error('Update user error:', e);
      return null;
    }
  },
  
  // Get total user count
  getUserCount: async () => {
    try {
      const response = await fetch(`${SUPABASE_URL}/rest/v1/br_users?select=id`, {
        headers: {
          'apikey': SUPABASE_KEY,
          'Authorization': `Bearer ${SUPABASE_KEY}`,
          'Prefer': 'count=exact',
          'Range': '0-0',
        },
      });
      const range = response.headers.get('content-range') || '0-0/0';
      const count = parseInt(range.split('/')[1] || '0', 10);
      return count;
    } catch {
      return 0;
    }
  },
  
  // Get latest user
  getLatestUser: async () => {
    try {
      const users = await supabaseFetch('br_users?select=payload&order=updated_at.desc&limit=1');
      return users?.[0]?.payload || null;
    } catch {
      return null;
    }
  },
};

// Local fallback when Supabase is not configured
const LOCAL_KEY = 'br10-users';

export const localDB = {
  getUsers: () => {
    try {
      return JSON.parse(localStorage.getItem(LOCAL_KEY) || '[]');
    } catch {
      return [];
    }
  },
  
  saveUsers: (users: any[]) => {
    localStorage.setItem(LOCAL_KEY, JSON.stringify(users));
  },
  
  getUserByCode: (code: string) => {
    const users = localDB.getUsers();
    return users.find((u: any) => String(u.code).toUpperCase() === code.toUpperCase()) || null;
  },
  
  getUserByUsername: (username: string) => {
    const users = localDB.getUsers();
    return users.find((u: any) => u.un === username) || null;
  },
  
  createUser: (user: any) => {
    const users = localDB.getUsers();
    users.push(user);
    localDB.saveUsers(users);
    return user;
  },
  
  updateUser: (user: any) => {
    const users = localDB.getUsers();
    const index = users.findIndex((u: any) => u.id === user.id);
    if (index >= 0) {
      users[index] = user;
      localDB.saveUsers(users);
    }
    return user;
  },
  
  getUserCount: () => {
    return localDB.getUsers().length;
  },
  
  getLatestUser: () => {
    const users = localDB.getUsers();
    return users[users.length - 1] || null;
  },
};

// Universal database interface (uses Supabase if available, otherwise local)
export const universalDB = {
  getUserByCode: async (code: string) => {
    if (SUPABASE_ENABLED) {
      const user = await db.getUserByCode(code);
      if (user) return user;
    }
    return localDB.getUserByCode(code);
  },
  
  getUserByUsername: async (username: string) => {
    if (SUPABASE_ENABLED) {
      const user = await db.getUserByUsername(username);
      if (user) return user;
    }
    return localDB.getUserByUsername(username);
  },
  
  createUser: async (user: any) => {
    if (SUPABASE_ENABLED) {
      const saved = await db.createUser(user);
      if (saved) return saved;
    }
    return localDB.createUser(user);
  },
  
  updateUser: async (user: any) => {
    if (SUPABASE_ENABLED) {
      const saved = await db.updateUser(user);
      if (saved) return saved;
    }
    return localDB.updateUser(user);
  },
  
  getUserCount: async () => {
    if (SUPABASE_ENABLED) {
      return await db.getUserCount();
    }
    return localDB.getUserCount();
  },
  
  getLatestUser: async () => {
    if (SUPABASE_ENABLED) {
      return await db.getLatestUser();
    }
    return localDB.getLatestUser();
  },
};

export default { db, localDB, universalDB, SUPABASE_ENABLED };
