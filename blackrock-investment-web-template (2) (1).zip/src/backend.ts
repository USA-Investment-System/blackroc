import type { User } from './store';
import { universalDB, SUPABASE_ENABLED } from './supabase';

export function backendMode() {
  return SUPABASE_ENABLED ? 'supabase' : 'local';
}

export async function sha256(text: string) {
  const enc = new TextEncoder().encode(text);
  const buf = await crypto.subtle.digest('SHA-256', enc);
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

export function normalizeUser<T extends Partial<User> & Record<string, any>>(u: T): User {
  const inviteLink = (code: string) => {
    try {
      const basePath = location.pathname.replace(/\/?index\.html$/i, '').replace(/\/$/, '');
      return `${location.origin}${basePath || ''}?code=${code}`;
    } catch {
      return 'blackrock.app?code=' + code;
    }
  };
  
  const out: any = {
    id: Date.now(), un: '', pw: '', code: '', ref: '', phone: '', wilaya: '',
    balance: 0, taskBal: 0, refEarn: 0, teamCount: 0,
    wheelSpins: 0, m1Refs: 0, level: null, totalEarned: 0,
    avatar: null, joined: new Date().toISOString(), joinedVia: null,
    notifs: [], investments: [], investEarned: 0, withdrawals: [],
    upgradeRequests: [], team: [], loginStreak: 0, badges: [], activityLog: [],
    showLiveActivity: true, profileCompleted: false,
    ...u,
  };
  out.investments ||= [];
  out.withdrawals ||= [];
  out.upgradeRequests ||= [];
  out.team ||= [];
  out.notifs ||= [];
  out.activityLog ||= [];
  out.badges ||= [];
  if (!out.ref || String(out.ref).includes('?ref=') || String(out.ref).includes('/ref/') || String(out.ref).includes('/invite') || !String(out.ref).includes('?code=')) {
    out.ref = inviteLink(out.code);
  }
  return out as User;
}

export async function loginUser(username: string, password: string): Promise<User | null> {
  const hash = await sha256(password);
  const user = await universalDB.getUserByUsername(username);
  if (!user) return null;
  const storedHash = (user as any).passwordHash;
  if (storedHash ? storedHash === hash : user.pw === password) return normalizeUser(user);
  return null;
}

export async function usernameExists(username: string) {
  const user = await universalDB.getUserByUsername(username);
  return Boolean(user);
}

export async function findUserByCode(code: string) {
  const clean = code.toUpperCase();
  return await universalDB.getUserByCode(clean);
}

export async function createUser(user: User, password: string) {
  const payload = normalizeUser({ ...user, pw: '', passwordHash: await sha256(password) } as any);
  return await universalDB.createUser(payload);
}

export async function saveUser(user: User) {
  const payload = normalizeUser(user);
  return await universalDB.updateUser(payload);
}

export async function updateUserByCode(code: string, updater: (user: User) => User) {
  const current = await findUserByCode(code);
  if (!current) return null;
  const next = normalizeUser(updater(current));
  await saveUser(next);
  return next;
}

export async function getPublicStats() {
  const count = await universalDB.getUserCount();
  const latest = await universalDB.getLatestUser();
  return { count, latestName: latest?.un || 'مستخدم' };
}
